package com.mandeep.jarvis

import android.Manifest
import android.app.Activity
import android.app.SearchManager
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.MediaStore
import android.telephony.TelephonyManager
import android.provider.Settings
import android.telephony.SmsManager
import android.view.KeyEvent
import org.json.JSONObject
import java.util.Locale

/**
 * Result of running an action.
 * message  = extra thing to say (usually a problem), or null
 * followUp = data the brain should turn into an answer (e.g. notifications)
 * task     = a goal for the on-screen agent (Jarvis taps/types by itself)
 * confirm  = this action needs a yes from the user first; text describes it
 * pressSend = a chat was opened with the message typed; screen control should tap Send
 */
data class ActionResult(
    val message: String? = null,
    val followUp: String? = null,
    val task: String? = null,
    val confirm: String? = null,
    val pressSend: Boolean = false,
    /** Type this into the app that's open right now (and send if [typeSend]). */
    val typeText: String? = null,
    val typeSend: Boolean = false,
)

/** Carries out the phone action the brain asked for. */
class Actions(private val activity: Context) {

    private fun p(pa: Boolean, punjabi: String, english: String) = if (pa) punjabi else english

    fun run(action: JSONObject?, pa: Boolean, confirmed: Boolean = false): ActionResult {
        if (action == null) return ActionResult()
        return try {
            when (action.optString("type", "none")) {
                "open_app" -> msg(openApp(action.optString("name"), pa))
                "youtube" -> {
                    if (action.optBoolean("song", false)) Playlist.add(activity, action.optString("query"))
                    msg(
                        if (CarAudio.inCar(activity)) playMusic(action.optString("query"), "youtube music")
                        else youtube(action.optString("query"))
                    )
                }
                "web_search" -> msg(webSearch(action.optString("query")))
                "maps" -> msg(view("geo:0,0?q=" + Uri.encode(action.optString("query"))))
                "dial", "call" -> msg(call(action, pa))
                "sms" -> sms(action, pa, confirmed)
                "whatsapp_to" -> whatsappTo(action, pa, confirmed)
                "whatsapp_message" -> msg(whatsappShare(action.optString("text")))
                "alarm" -> msg(alarm(action.optInt("hour", 7), action.optInt("minute", 0), action.optString("label", "")))
                "timer" -> msg(timer(action.optInt("seconds", 60)))
                "torch" -> msg(torch(action.optBoolean("on", true), pa))
                "media" -> msg(media(action.optString("cmd", "play")))
                "volume" -> msg(volume(action))
                "brightness" -> msg(brightness(action.optInt("level", 50), pa))
                "ringer" -> msg(ringer(action.optString("mode", "normal"), pa))
                "global" -> msg(global(action.optString("cmd"), pa))
                "read_notifications" -> notifications(pa)
                "settings" -> msg(settings(action.optString("page", "main")))
                "screen_task" -> screenTask(action)
                "set_language" -> {
                    val toPa = action.optString("lang").lowercase(Locale.ROOT).startsWith("pa")
                    activity.getSharedPreferences("jarvis", Context.MODE_PRIVATE).edit().putBoolean("punjabi", toPa).apply()
                    ActionResult()
                }
                "play_artist" -> {
                    val who = action.optString("artist").ifBlank { action.optString("query") }
                    playSinger(who, CarAudio.inCar(activity) || norm(action.optString("app")) == "youtubemusic")
                    ActionResult()
                }
                "play_music" -> {
                    Playlist.add(activity, action.optString("query"))
                    msg(playMusic(action.optString("query"), action.optString("app")))
                }
                "play_playlist" -> msg(playPlaylist(action.optBoolean("shuffle", false), pa))
                "search_in_app" -> msg(searchIn(action.optString("app"), action.optString("query"), pa))
                "type_here" -> if (JarvisAccess.instance == null)
                    ActionResult(p(pa, "ਇਸ ਲਈ ਸੈਟਿੰਗ ਵਿੱਚ Screen control ਚਾਲੂ ਕਰੋ।", "Turn on Screen control in Settings for this."))
                else ActionResult(typeText = action.optString("text"), typeSend = action.optBoolean("send", true))
                "playlist_remove" -> msg(
                    if (Playlist.remove(activity, action.optString("query"))) p(pa, "ਪਲੇਲਿਸਟ ਵਿੱਚੋਂ ਕੱਢ ਦਿੱਤਾ।", "Removed from your playlist.")
                    else p(pa, "ਇਹ ਗਾਣਾ ਪਲੇਲਿਸਟ ਵਿੱਚ ਨਹੀਂ ਮਿਲਿਆ।", "That song isn't in your playlist.")
                )
                "navigate" -> msg(navigate(action.optString("query")))
                else -> ActionResult()
            }
        } catch (e: ActivityNotFoundException) {
            ActionResult(p(pa, "ਇਹ ਕੰਮ ਕਰਨ ਵਾਲੀ ਐਪ ਫ਼ੋਨ ਵਿੱਚ ਨਹੀਂ ਲੱਭੀ।", "I couldn't find an app for that."))
        } catch (e: SecurityException) {
            ActionResult(p(pa, "ਇਸ ਕੰਮ ਲਈ ਪਰਮਿਸ਼ਨ ਚਾਹੀਦੀ ਹੈ — ⚙ ਵਿੱਚ ਜਾ ਕੇ ਦਿਓ।", "I need a permission for that — open ⚙ to grant it."))
        } catch (e: Exception) {
            ActionResult(p(pa, "ਮਾਫ਼ ਕਰਨਾ, ਇਹ ਕੰਮ ਨਹੀਂ ਹੋ ਸਕਿਆ।", "Sorry, that didn't work."))
        }
    }

    private fun msg(s: String?) = ActionResult(message = s)

    private fun start(intent: Intent) {
        // From the floating mini panel (not an Activity) a new task is needed.
        if (activity !is Activity) intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        activity.startActivity(intent)
    }

    private fun view(uri: String): String? {
        start(Intent(Intent.ACTION_VIEW, Uri.parse(uri)))
        return null
    }

    private fun granted(perm: String) =
        activity.checkSelfPermission(perm) == PackageManager.PERMISSION_GRANTED

    // ------------------------------------------------------------------ apps

    private fun openApp(name: String, pa: Boolean): String? {
        val n = ALIASES[name.lowercase(Locale.ROOT).trim()] ?: name
        if (norm(n).isEmpty()) return null
        val intent = findLaunch(n)
            ?: return p(pa, "\"$name\" ਐਪ ਫ਼ੋਨ ਵਿੱਚ ਨਹੀਂ ਲੱਭੀ।", "I couldn't find \"$name\" on your phone.")
        return try { start(intent); null } catch (e: Exception) {
            p(pa, "\"$name\" ਖੁੱਲ੍ਹ ਨਹੀਂ ਸਕੀ।", "\"$name\" wouldn't open.")
        }
    }

    private fun norm(s: String) = s.lowercase(Locale.ROOT).filter { it.isLetterOrDigit() }

    /**
     * Instant path for "open X" / "X ਖੋਲ੍ਹ" — opens the app right away without asking the AI.
     * Returns what to say, or null when the sentence isn't a plain "open app" request.
     */
    /**
     * Instant commands — done right away on the phone, no AI and no internet needed:
     * songs, playlist, torch, volume, pause/next, calls and opening apps.
     * Returns what to say, or null when the AI should handle it.
     */
    fun quickOpen(text: String, pa: Boolean): String? {
        val t = Offline.clean(text)
        val words = t.trim().split(" ").size
        val online = Offline.online(activity)

        // ---- songs
        if (Offline.has(t, Offline.PLAYLIST) && (Offline.has(t, Offline.PLAY_VERBS) || words <= 3)) {
            if (online) return playPlaylist(t.contains("shuffle") || t.contains("mix"), pa) ?: p(pa, "ਤੁਹਾਡੀ ਪਲੇਲਿਸਟ ਲਾ ਰਿਹਾ ਹਾਂ।", "Playing your playlist.")
            return playOffline("", pa)
        }
        if (Offline.isSongRequest(t)) {
            val q = Offline.songQuery(t)
            if (!online) return playOffline(q, pa)
            val query = q.ifEmpty { "latest punjabi songs" }
            // only a singer's name → play a queue of their latest songs (don't ask which one)
            val singer = Offline.singerOnly(q) ?: if (q.isEmpty()) "latest punjabi" else null
            if (singer != null) {
                playSinger(singer, t.contains("youtube music") || CarAudio.inCar(activity))
                return p(pa, "$singer ਦੇ ਨਵੇਂ ਗਾਣੇ ਲਾ ਰਿਹਾ ਹਾਂ।", "Playing $singer's latest songs.")
            }
            Playlist.add(activity, query)
            when {
                t.contains("spotify") -> playMusic(query, "spotify")
                t.contains("youtube music") || t.contains("yt music") || t.contains("ytmusic") -> playMusic(query, "youtube music")
                t.contains(" youtube ") || t.contains("ਯੂਟਿਊਬ") || t.contains("यूट्यूब") ->
                    if (CarAudio.inCar(activity)) playMusic(query, "youtube music") else youtube(query)
                else -> playMusic(query, "")
            }
            return p(pa, "ਲਾ ਰਿਹਾ ਹਾਂ।", "Playing it.")
        }

        // ---- search inside an app: "YouTube te Sidhu de gaane labh", "search shoes on Amazon"
        if (Offline.has(t, listOf("search", "labh", "lab", "khoj", "find", "dhoond", "ਲੱਭ", "ਲਭ", "ਖੋਜ", "ਸਰਚ", "खोज", "ढूंढ", "सर्च")) && online) {
            val apps = listOf("youtube music", "youtube", "spotify", "play store", "maps", "google", "chrome", "amazon", "instagram",
                "tiktok", "facebook", "whatsapp", "netflix", "snapchat", "ebay", "ਯੂਟਿਊਬ", "यूट्यूब", "ਇੰਸਟਾਗ੍ਰਾਮ", "ਫੇਸਬੁੱਕ", "ਵਟਸਐਪ")
            val app = apps.firstOrNull { t.contains(" $it ") }
            if (app != null) {
                var q = t
                for (w in listOf(app, "search", "kar", "karo", "de", "do", "te", "ਤੇ", "on", "in", "par", "pe", "ch", "vich", "ਵਿੱਚ",
                    "labh", "lab", "khoj", "find", "dhoond", "ਲੱਭ", "ਲਭ", "ਖੋਜ", "ਸਰਚ", "ਕਰ", "ਦੇ", "खोज", "ढूंढ", "सर्च", "कर", "पर", "में",
                    "for", "the", "please", "ji", "ਜੀ", "app", "ਐਪ", "nu", "ਨੂੰ"))
                    q = q.replace(" $w ", " ")
                q = q.trim().replace(Regex("\\s+"), " ")
                val appName = ALIASES[app] ?: app
                if (q.isNotEmpty()) return searchIn(appName, q, pa) ?: p(pa, "$appName ਤੇ ਲੱਭ ਰਿਹਾ ਹਾਂ।", "Searching $appName.")
            }
        }

        // ---- torch
        if (Offline.has(t, Offline.TORCH)) {
            val on = !Offline.has(t, Offline.OFF)
            return torch(on, pa) ?: p(pa, if (on) "ਟਾਰਚ ਚਾਲੂ।" else "ਟਾਰਚ ਬੰਦ।", if (on) "Torch on." else "Torch off.")
        }

        // ---- volume
        if (Offline.has(t, Offline.VOLUME)) {
            val change = when {
                Offline.has(t, Offline.MUTE) || Offline.has(t, Offline.OFF) -> "mute"
                Offline.has(t, Offline.DOWN) -> "down"
                Offline.has(t, Offline.UP) -> "up"
                else -> null
            }
            if (change != null) {
                val a = JSONObject().put("change", change)
                volume(a)
                if (change != "mute") volume(a) // two steps feels right
                return p(pa, "ਠੀਕ ਹੈ।", "Done.")
            }
        }

        // ---- music control
        if (words <= 4 || Offline.has(t, Offline.SONG)) {
            val cmd = when {
                Offline.has(t, Offline.NEXT) -> "next"
                Offline.has(t, Offline.PREV) -> "previous"
                Offline.has(t, Offline.PAUSE) -> "pause"
                else -> null
            }
            if (cmd != null) { media(cmd); return p(pa, "ਠੀਕ ਹੈ।", "Okay.") }
        }

        // ---- calls ("Papa nu call kar")
        Offline.callName(t)?.let { who ->
            val a = JSONObject().put("contact", who)
            if (target(a) != null) { call(a, pa); return p(pa, "$who ਨੂੰ ਕਾਲ ਕਰ ਰਿਹਾ ਹਾਂ।", "Calling $who.") }
            if (!online) return noContact(a, pa)
        }

        return openQuick(text, pa)
    }

    /**
     * A singer's latest songs, one after another: finds their newest songs on YouTube and plays them as a queue.
     * In the car (or when asked) YouTube Music plays the artist instead.
     */
    private fun playSinger(singer: String, ytMusic: Boolean) {
        val ytm = "com.google.android.apps.youtube.music"
        if (ytMusic && installed(ytm)) {
            try {
                start(Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH)
                    .putExtra(SearchManager.QUERY, singer)
                    .putExtra(MediaStore.EXTRA_MEDIA_ARTIST, singer)
                    .putExtra(MediaStore.EXTRA_MEDIA_FOCUS, MediaStore.Audio.Artists.ENTRY_CONTENT_TYPE)
                    .setPackage(ytm))
                return
            } catch (e: Exception) {}
        }
        val main = android.os.Handler(android.os.Looper.getMainLooper())
        Thread {
            val ids = try { YouTubeFinder.videoIds("$singer new songs", 15) } catch (e: Exception) { emptyList() }
            main.post {
                try {
                    if (ids.size >= 2) {
                        val url = "https://www.youtube.com/watch_videos?video_ids=" + ids.joinToString(",")
                        try { start(Intent(Intent.ACTION_VIEW, Uri.parse(url)).setPackage("com.google.android.youtube")) }
                        catch (e: ActivityNotFoundException) { view(url) }
                    } else youtube("$singer new song")
                } catch (e: Exception) {}
            }
        }.start()
    }

    /** No internet: play a song saved on the phone. */
    private fun playOffline(q: String, pa: Boolean): String {
        if (!Offline.canReadSongs(activity))
            return p(pa, "ਨੈੱਟ ਨਹੀਂ ਚੱਲਦਾ। ਫ਼ੋਨ ਦੇ ਗਾਣੇ ਚਲਾਉਣ ਲਈ Singh AI ਨੂੰ ਗਾਣਿਆਂ (Music) ਦੀ ਇਜਾਜ਼ਤ ਦਿਓ।",
                "No internet. To play songs saved on the phone, allow Singh AI to access music.")
        val song = Offline.findLocalSong(activity, q)
        if (song == null) {
            val any = if (q.isNotEmpty()) null else Offline.findLocalSong(activity, "")
            if (any != null && Offline.playLocal(activity, any.first)) return p(pa, "ਫ਼ੋਨ ਵਿੱਚੋਂ ਗਾਣਾ ਲਾ ਰਿਹਾ ਹਾਂ।", "Playing a song from your phone.")
            return p(pa, "ਨੈੱਟ ਨਹੀਂ ਚੱਲਦਾ, ਤੇ ਇਹ ਗਾਣਾ ਫ਼ੋਨ ਵਿੱਚ ਨਹੀਂ ਮਿਲਿਆ।", "No internet, and that song isn't saved on the phone.")
        }
        Offline.playLocal(activity, song.first)
        return p(pa, "ਫ਼ੋਨ ਵਿੱਚੋਂ ${song.second} ਲਾ ਰਿਹਾ ਹਾਂ।", "Playing ${song.second} from your phone.")
    }

    /** Only "open X" (used by Live so a spoken "open YouTube" always opens, even if the AI forgets). */
    fun openOnly(text: String, pa: Boolean): String? = try { openQuick(text, pa) } catch (e: Exception) { null }

    private fun openQuick(text: String, pa: Boolean): String? {
        var t = " " + text.lowercase(Locale.ROOT).replace(Regex("[.,!?।]"), " ") + " "
        val verbs = listOf(
            "open kar do", "open kar de", "open karo", "open kar", "open", "launch", "start", "kholo", "khol do", "khol de", "kholde", "khol",
            "chalu kar", "chalao", "chala", "te ja", "ch ja",
            "ਖੋਲ੍ਹ ਦਿਓ", "ਖੋਲ੍ਹ ਦੇ", "ਖੋਲ੍ਹੋ", "ਖੋਲ੍ਹ", "ਖੋਲੋ", "ਖੋਲ", "ਓਪਨ ਕਰ", "ਓਪਨ", "ਚਲਾਓ", "ਚਲਾ", "ਚਾਲੂ ਕਰ",
            "खोल दो", "खोल दे", "खोलो", "खोल", "ओपन कर", "ओपन", "चलाओ", "चालू कर"
        )
        val verb = verbs.firstOrNull { t.contains(" $it ") } ?: return null
        t = t.replace(" $verb ", " ")
        for (f in listOf("app", "ਐਪ", "ऐप", "एप", "application", "please", "ji", "ਜੀ", "जी", "the", "nu", "ਨੂੰ", "को", "de", "ਦੇ",
            "do", "my", "mera", "meri", "ਮੇਰਾ", "ਮੇਰੀ", "singh", "ai", "ਸਿੰਘ", "zara", "ਜ਼ਰਾ", "hun", "ਹੁਣ", "jaldi"))
            t = t.replace(" $f ", " ")
        var name = t.trim().replace(Regex("\\s+"), " ")
        if (name.isEmpty() || name.split(" ").size > 4) return null
        name = ALIASES[name] ?: ALIASES[name.replace(" ", "")] ?: name
        if (norm(name).length < 2) return null
        val i = findLaunch(name) ?: return null
        start(i)
        return p(pa, "ਖੋਲ੍ਹ ਰਿਹਾ ਹਾਂ।", "Opening it.")
    }

    /** Edit distance, to understand slightly wrong names ("whatsap", "insta gram", "you tube"). */
    private fun dist(a: String, b: String): Int {
        val d = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            var prev = d[0]; d[0] = i
            for (j in 1..b.length) {
                val tmp = d[j]
                d[j] = minOf(d[j] + 1, d[j - 1] + 1, prev + if (a[i - 1] == b[j - 1]) 0 else 1)
                prev = tmp
            }
        }
        return d[b.length]
    }

    /**
     * The best way to open what the user named: an installed app (exact, starts-with, contains, close spelling),
     * or the phone's own app for that job (camera, phone, messages, settings, gallery, contacts, calendar, clock,
     * calculator, email, browser, music, maps, files).
     */
    private fun findLaunch(name: String): Intent? {
        val wanted = norm(name)
        if (wanted.isEmpty()) return null
        val pm = activity.packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), PackageManager.MATCH_ALL)
            .map { it.activityInfo.packageName to norm(it.loadLabel(pm).toString()) }
        val best = apps.firstOrNull { it.second == wanted }
            ?: apps.firstOrNull { it.second.startsWith(wanted) && wanted.length >= 3 }
            ?: apps.firstOrNull { wanted.length >= 4 && it.second.contains(wanted) }
            ?: apps.firstOrNull { it.second.length >= 4 && wanted.contains(it.second) }
            ?: apps.filter { wanted.length >= 5 }.minByOrNull { dist(it.second, wanted) }?.takeIf { dist(it.second, wanted) <= 2 }
            ?: apps.firstOrNull { wanted.length >= 4 && it.first.lowercase(Locale.ROOT).contains(wanted) }
        best?.let { b -> pm.getLaunchIntentForPackage(b.first)?.let { return it } }
        return systemApp(wanted)
    }

    private fun systemApp(w: String): Intent? {
        fun cat(c: String) = Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, c)
        val i: Intent = when {
            w.contains("camera") || w == "ਕੈਮਰਾ" -> Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)
            w == "phone" || w.contains("dialer") || w.contains("dial") || w == "call" -> Intent(Intent.ACTION_DIAL)
            w.contains("message") || w == "sms" || w.contains("text") -> cat(Intent.CATEGORY_APP_MESSAGING)
            w.contains("setting") -> Intent(Settings.ACTION_SETTINGS)
            w.contains("gallery") || w.contains("photo") || w.contains("picture") -> cat(Intent.CATEGORY_APP_GALLERY)
            w.contains("contact") -> cat(Intent.CATEGORY_APP_CONTACTS)
            w.contains("calendar") -> cat(Intent.CATEGORY_APP_CALENDAR)
            w.contains("clock") || w.contains("alarm") -> Intent(AlarmClock.ACTION_SHOW_ALARMS)
            w.contains("calculator") -> cat(Intent.CATEGORY_APP_CALCULATOR)
            w.contains("email") || w.contains("mail") -> cat(Intent.CATEGORY_APP_EMAIL)
            w.contains("browser") || w.contains("internet") -> cat(Intent.CATEGORY_APP_BROWSER)
            w.contains("music") -> cat(Intent.CATEGORY_APP_MUSIC)
            w.contains("map") || w.contains("navigation") -> cat(Intent.CATEGORY_APP_MAPS)
            w.contains("file") -> cat(Intent.CATEGORY_APP_FILES)
            w.contains("wifi") -> Intent(Settings.ACTION_WIFI_SETTINGS)
            w.contains("bluetooth") -> Intent(Settings.ACTION_BLUETOOTH_SETTINGS)
            else -> return null
        }
        return i.takeIf { it.resolveActivity(activity.packageManager) != null || it.selector != null }
    }

    companion object {
        /** Spoken app names (Punjabi / Hindi script) → the app's English name. */
        private val ALIASES = mapOf(
            "ਯੂਟਿਊਬ" to "youtube", "ਯੂ ਟਿਊਬ" to "youtube", "यूट्यूब" to "youtube",
            "ਵਟਸਐਪ" to "whatsapp", "ਵਹਟਸਐਪ" to "whatsapp", "ਵਟਸ ਐਪ" to "whatsapp", "व्हाट्सएप" to "whatsapp",
            "ਇੰਸਟਾਗ੍ਰਾਮ" to "instagram", "ਇੰਸਟਾ" to "instagram", "इंस्टाग्राम" to "instagram",
            "ਫੇਸਬੁੱਕ" to "facebook", "ਫੇਸਬੁਕ" to "facebook", "फेसबुक" to "facebook",
            "ਕੈਮਰਾ" to "camera", "कैमरा" to "camera", "ਗੈਲਰੀ" to "gallery", "गैलरी" to "gallery",
            "ਸੈਟਿੰਗ" to "settings", "ਸੈਟਿੰਗਜ਼" to "settings", "ਸੈਟਿੰਗਸ" to "settings", "सेटिंग" to "settings",
            "ਕਰੋਮ" to "chrome", "क्रोम" to "chrome", "ਮੈਪ" to "maps", "ਮੈਪਸ" to "maps", "मैप" to "maps",
            "ਸਪੋਟੀਫਾਈ" to "spotify", "ਟਿਕਟੌਕ" to "tiktok", "ਟਿਕ ਟੌਕ" to "tiktok", "ਸਨੈਪਚੈਟ" to "snapchat",
            "ਸਨੈਪ" to "snapchat", "ਜੀਮੇਲ" to "gmail", "ਨੈੱਟਫਲਿਕਸ" to "netflix", "ਨੈਟਫਲਿਕਸ" to "netflix",
            "ਕੈਲਕੁਲੇਟਰ" to "calculator", "ਘੜੀ" to "clock", "ਫ਼ੋਨ" to "phone", "ਫੋਨ" to "phone",
            "ਮੈਸੇਜ" to "messages", "ਮੈਸੇਜਸ" to "messages", "ਟੈਲੀਗ੍ਰਾਮ" to "telegram", "ਟੈਲੀਗਰਾਮ" to "telegram",
            "ਐਮਾਜ਼ਾਨ" to "amazon", "ਪਲੇ ਸਟੋਰ" to "play store", "ਪਲੇਸਟੋਰ" to "play store",
            "ਗੂਗਲ" to "google", "ਜੀਮੇਲ" to "gmail", "ਕੈਲੰਡਰ" to "calendar", "ਸੰਪਰਕ" to "contacts", "ਕਾਂਟੈਕਟ" to "contacts",
            "ਫਾਈਲਾਂ" to "my files", "ਫਾਈਲ" to "my files", "ਨੋਟਸ" to "notes", "ਮੌਸਮ" to "weather", "ਯੂਟਿਊਬ ਮਿਊਜ਼ਿਕ" to "youtube music",
            "ਗੂਗਲ ਮੈਪਸ" to "maps", "ਗੂਗਲ ਮੈਪ" to "maps", "ਰਿਕਾਰਡਰ" to "voice recorder", "ਫੋਟੋਆਂ" to "gallery", "ਫੋਟੋ" to "gallery",
            "ਬ੍ਰਾਊਜ਼ਰ" to "chrome", "ਇੰਟਰਨੈੱਟ" to "internet", "ਗੇਮ" to "game", "ਸਨੈਪਚੈਟ" to "snapchat", "ਲਿੰਕਡਇਨ" to "linkedin",
            "ਪੇਟੀਐਮ" to "paytm", "ਫੋਨਪੇ" to "phonepe", "ਗੂਗਲ ਪੇ" to "google pay", "ਟਵਿੱਟਰ" to "x", "ਥ੍ਰੈਡਸ" to "threads",
            "you tube" to "youtube", "what's app" to "whatsapp", "whats app" to "whatsapp", "insta" to "instagram", "fb" to "facebook",
            "yt music" to "youtube music", "gpay" to "google pay", "playstore" to "play store", "dialer" to "phone", "photos" to "gallery",
            "यूट्यूब" to "youtube", "इंस्टा" to "instagram", "गूगल" to "google", "कैलकुलेटर" to "calculator", "कॉन्टैक्ट" to "contacts"
        )
    }

    /**
     * Plays the top YouTube video for [query] straight away (not just the search page).
     * Finds the video in the background, then opens it in the YouTube app.
     */
    private fun youtube(query: String): String? {
        val main = android.os.Handler(android.os.Looper.getMainLooper())
        Thread {
            val id = try { YouTubeFinder.firstVideoId(query) } catch (e: Exception) { null }
            main.post {
                try {
                    if (id != null) {
                        val i = Intent(Intent.ACTION_VIEW, Uri.parse("vnd.youtube:$id"))
                            .setPackage("com.google.android.youtube")
                        try { start(i) } catch (e: ActivityNotFoundException) {
                            view("https://www.youtube.com/watch?v=$id")
                        }
                    } else youtubeSearch(query)
                } catch (e: Exception) {
                    try { youtubeSearch(query) } catch (e2: Exception) {}
                }
            }
        }.start()
        return null
    }

    private fun youtubeSearch(query: String) {
        try {
            start(Intent(Intent.ACTION_SEARCH).setPackage("com.google.android.youtube").putExtra("query", query))
        } catch (e: ActivityNotFoundException) {
            view("https://www.youtube.com/results?search_query=" + Uri.encode(query))
        }
    }

    /** Finds an installed app by its spoken name → package. */
    private fun findPackage(name: String): String? {
        val wanted = norm(ALIASES[name.lowercase(Locale.ROOT).trim()] ?: name)
        if (wanted.isEmpty()) return null
        val pm = activity.packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), PackageManager.MATCH_ALL)
            .map { it.activityInfo.packageName to norm(it.loadLabel(pm).toString()) }
        return (apps.firstOrNull { it.second == wanted } ?: apps.firstOrNull { it.second.startsWith(wanted) }
            ?: apps.firstOrNull { it.second.contains(wanted) })?.first
    }

    /** "Search X on <app>": straight to the app's results page when the app supports it, otherwise screen control types it. */
    private fun searchIn(app: String, query: String, pa: Boolean): String? {
        val a = norm(app)
        val q = query.trim()
        if (q.isEmpty()) return openApp(app, pa)
        fun tryStart(i: Intent): Boolean = try { start(i); true } catch (e: Exception) { false }
        val done = when {
            a == "youtube" || a == "yt" -> { youtubeSearch(q); true }
            a.contains("youtubemusic") || a == "ytmusic" -> tryStart(Intent(Intent.ACTION_VIEW,
                Uri.parse("https://music.youtube.com/search?q=" + Uri.encode(q))).setPackage("com.google.android.apps.youtube.music"))
            a == "spotify" -> tryStart(Intent(Intent.ACTION_VIEW, Uri.parse("spotify:search:" + Uri.encode(q))))
            a.contains("playstore") || a == "play" -> tryStart(Intent(Intent.ACTION_VIEW, Uri.parse("market://search?q=" + Uri.encode(q))))
            a.contains("map") -> tryStart(Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(q))))
            a == "google" || a == "chrome" || a.isEmpty() -> { webSearch(q); true }
            a == "amazon" -> tryStart(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.amazon.com/s?k=" + Uri.encode(q))))
            a == "ebay" -> tryStart(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.ebay.com/sch/i.html?_nkw=" + Uri.encode(q))))
            else -> false
        }
        if (done) return null
        val pkg = findPackage(app) ?: return p(pa, "\"$app\" ਐਪ ਫ਼ੋਨ ਵਿੱਚ ਨਹੀਂ ਲੱਭੀ।", "I couldn't find \"$app\" on your phone.")
        val acc = JarvisAccess.instance
            ?: return p(pa, "ਐਪ ਦੇ ਅੰਦਰ ਲੱਭਣ ਲਈ ਸੈਟਿੰਗ ਵਿੱਚ Screen control ਚਾਲੂ ਕਰੋ।", "Turn on Screen control in Settings to search inside apps.")
        acc.searchInApp(pkg, q, pa)
        return null
    }

    private fun webSearch(query: String): String? {
        try {
            start(Intent(Intent.ACTION_WEB_SEARCH).putExtra(SearchManager.QUERY, query))
        } catch (e: ActivityNotFoundException) {
            view("https://www.google.com/search?q=" + Uri.encode(query))
        }
        return null
    }

    // -------------------------------------------------------------- contacts

    /** Finds the best matching contact: (name, number), or null. */
    private fun findContact(name: String): Pair<String, String>? {
        if (!granted(Manifest.permission.READ_CONTACTS)) return null
        val wanted = norm(name)
        if (wanted.isEmpty()) return null
        val words = name.lowercase(Locale.ROOT).split(" ").map { norm(it) }.filter { it.length > 1 }
        var best: Pair<String, String>? = null
        var bestScore = 0
        activity.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER
            ),
            null, null, null
        )?.use { c ->
            while (c.moveToNext()) {
                val display = c.getString(0) ?: continue
                val number = c.getString(1) ?: continue
                val n = norm(display)
                val score = when {
                    n == wanted -> 100
                    n.startsWith(wanted) -> 60
                    n.contains(wanted) -> 40
                    words.isNotEmpty() && words.all { n.contains(it) } -> 30
                    words.any { n.startsWith(it) } -> 10
                    else -> 0
                }
                if (score > bestScore) {
                    bestScore = score
                    best = display to number
                }
            }
        }
        return best
    }

    /** (display name, number) from an action with "number" or "contact". */
    private fun target(action: JSONObject): Pair<String, String>? {
        val number = action.optString("number").filter { it.isDigit() || it == '+' }
        if (number.length >= 3) return number to number
        return findContact(action.optString("contact"))
    }

    private fun noContact(action: JSONObject, pa: Boolean): String {
        val who = action.optString("contact")
        return if (!granted(Manifest.permission.READ_CONTACTS))
            p(pa, "ਸੰਪਰਕ ਦੇਖਣ ਦੀ ਪਰਮਿਸ਼ਨ ਨਹੀਂ — ⚙ ਵਿੱਚ ਜਾ ਕੇ ਦਿਓ।", "I can't see your contacts yet — grant it in ⚙.")
        else p(pa, "\"$who\" ਨਾਮ ਦਾ ਸੰਪਰਕ ਨਹੀਂ ਲੱਭਿਆ।", "I couldn't find a contact called \"$who\".")
    }

    private fun call(action: JSONObject, pa: Boolean): String? {
        val (_, number) = target(action) ?: return noContact(action, pa)
        val uri = Uri.parse("tel:" + Uri.encode(number))
        start(Intent(if (granted(Manifest.permission.CALL_PHONE)) Intent.ACTION_CALL else Intent.ACTION_DIAL, uri))
        return null
    }

    private fun sms(action: JSONObject, pa: Boolean, confirmed: Boolean): ActionResult {
        val (who, number) = target(action) ?: return ActionResult(noContact(action, pa))
        val text = action.optString("text")
        val send = action.optBoolean("send", true)
        if (!send || !granted(Manifest.permission.SEND_SMS)) {
            // No permission: open the messages app with the text ready.
            start(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(number))).putExtra("sms_body", text))
            return ActionResult()
        }
        @Suppress("DEPRECATION")
        val sm: SmsManager = if (Build.VERSION.SDK_INT >= 31)
            activity.getSystemService(SmsManager::class.java) else SmsManager.getDefault()
        sm.sendMultipartTextMessage(number, null, sm.divideMessage(text), null, null)
        return ActionResult(message = p(pa, "$who ਨੂੰ SMS ਭੇਜ ਦਿੱਤਾ।", "SMS sent to $who."))
    }

    /**
     * Opens the WhatsApp chat straight away with the message already typed (no searching),
     * then screen control taps Send — only when the user asked to send.
     */
    private fun whatsappTo(action: JSONObject, pa: Boolean, @Suppress("UNUSED_PARAMETER") confirmed: Boolean): ActionResult {
        val text = action.optString("text")
        val send = action.optBoolean("send", true)
        val contactName = action.optString("contact")
        val found = target(action)
        val intl = found?.let { intlNumber(it.second) }.orEmpty()

        if (intl.length < 8) {
            // Contact/number not found → let screen control search inside WhatsApp.
            val who = found?.first ?: contactName
            if (JarvisAccess.instance == null) return ActionResult(noContact(action, pa))
            openApp("WhatsApp", pa)
            return ActionResult(
                task = "WhatsApp is open. Tap the search icon, search \"$who\", open that chat, " +
                    "type exactly: \"$text\"" + (if (send) " and tap Send." else ". Do NOT send.") + " Then finish."
            )
        }

        val link = "https://api.whatsapp.com/send?phone=$intl" +
            (if (text.isNotEmpty()) "&text=" + Uri.encode(text) else "")
        var opened = false
        for (pkg in listOf("com.whatsapp", "com.whatsapp.w4b", null)) {
            try {
                val i = Intent(Intent.ACTION_VIEW, Uri.parse(link))
                if (pkg != null) i.setPackage(pkg)
                start(i)
                opened = true
                break
            } catch (e: ActivityNotFoundException) {}
        }
        if (!opened) return ActionResult(p(pa, "WhatsApp ਨਹੀਂ ਲੱਭਿਆ।", "WhatsApp isn't installed."))
        if (!send || text.isEmpty()) return ActionResult()
        if (JarvisAccess.instance == null) return ActionResult(
            p(pa, "ਸੁਨੇਹਾ ਲਿਖ ਦਿੱਤਾ — Send ਦਬਾ ਦਿਓ। Screen Control ਚਾਲੂ ਕਰੋ ਤਾਂ ਮੈਂ ਆਪ ਭੇਜਾਂਗਾ।",
                "Message typed — tap Send. Turn on Screen Control and I'll send it myself.")
        )
        return ActionResult(pressSend = true)
    }

    /** Turns a saved number like "(559) 555-0123" or "098765 43210" into "15595550123" / "919876543210". */
    private fun intlNumber(raw: String): String {
        val plus = raw.trim().startsWith("+")
        var d = raw.filter { it.isDigit() }
        if (plus) return d
        if (d.startsWith("00")) return d.drop(2)
        val cc = countryCode()
        if (d.startsWith("0")) d = d.trimStart('0')
        return when {
            cc == "1" && d.length == 11 && d.startsWith("1") -> d
            d.length <= 10 -> cc + d
            else -> d
        }
    }

    private fun countryCode(): String {
        val fromSim = try {
            val tm = activity.getSystemService(TelephonyManager::class.java)
            (tm?.simCountryIso?.takeIf { it.isNotBlank() } ?: tm?.networkCountryIso ?: "").lowercase(Locale.ROOT)
        } catch (e: Exception) { "" }
        val iso = fromSim.ifBlank { Locale.getDefault().country.lowercase(Locale.ROOT) }
        return when (iso) {
            "in" -> "91"; "gb" -> "44"; "au" -> "61"; "nz" -> "64"; "ae" -> "971"; "pk" -> "92"
            "it" -> "39"; "de" -> "49"; "fr" -> "33"; "es" -> "34"
            else -> "1" // US / Canada
        }
    }

    /** Opens the right app first, so screen control starts in the right place. */
    private fun screenTask(action: JSONObject): ActionResult {
        val app = action.optString("app")
        if (app.isNotBlank()) openApp(app, false)
        return ActionResult(task = action.optString("goal"))
    }

    private fun installed(pkg: String) = try { activity.packageManager.getPackageInfo(pkg, 0); true } catch (e: Exception) { false }

    /**
     * Plays a song. YouTube Music: finds the exact song first and opens it so it STARTS PLAYING
     * (just "searching" in YouTube Music only opened the app). Spotify: play-from-search.
     */
    private fun playMusic(query: String, app: String): String? {
        val a = norm(app)
        val ytm = "com.google.android.apps.youtube.music"
        if (a == "spotify" && installed("com.spotify.music")) {
            val i = Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH)
                .putExtra(SearchManager.QUERY, query)
                .putExtra(MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/*")
                .setPackage("com.spotify.music")
            try { start(i); return null } catch (e: Exception) {}
        }
        val wantYtm = a == "youtubemusic" || a == "ytmusic" || CarAudio.inCar(activity) || (a.isEmpty() && installed(ytm))
        if (a == "youtube" && !CarAudio.inCar(activity)) return youtube(query)
        if (!wantYtm || !installed(ytm)) return youtube(query)
        val main = android.os.Handler(android.os.Looper.getMainLooper())
        Thread {
            val id = try { YouTubeFinder.firstVideoId(query) } catch (e: Exception) { null }
            main.post {
                try {
                    if (id != null) {
                        start(Intent(Intent.ACTION_VIEW, Uri.parse("https://music.youtube.com/watch?v=$id")).setPackage(ytm))
                    } else {
                        start(Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH)
                            .putExtra(SearchManager.QUERY, query)
                            .putExtra(MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/*")
                            .setPackage(ytm))
                    }
                } catch (e: Exception) {
                    try { youtube(query) } catch (e2: Exception) {}
                }
            }
        }.start()
        return null
    }

    /** Plays "meri playlist" — all saved songs in one go on YouTube (YouTube Music in the car). */
    private fun playPlaylist(shuffle: Boolean, pa: Boolean): String? {
        val ids = Playlist.ids(activity, shuffle)
        if (ids.isEmpty()) {
            val first = Playlist.ordered(activity).firstOrNull()
                ?: return p(pa, "ਤੁਹਾਡੀ ਪਲੇਲਿਸਟ ਹਾਲੇ ਖਾਲੀ ਹੈ। ਜਿਹੜੇ ਗਾਣੇ ਲਵਾਓਗੇ, ਉਹ ਆਪੇ ਜੁੜਦੇ ਜਾਣਗੇ।",
                    "Your playlist is empty for now. Songs you play get added by themselves.")
            return youtube(first.query)
        }
        val list = ids.joinToString(",")
        if (CarAudio.inCar(activity)) {
            try {
                start(Intent(Intent.ACTION_VIEW, Uri.parse("https://music.youtube.com/watch_videos?video_ids=$list"))
                    .setPackage("com.google.android.apps.youtube.music"))
                return null
            } catch (e: Exception) { /* use YouTube below */ }
        }
        val url = "https://www.youtube.com/watch_videos?video_ids=$list"
        try {
            start(Intent(Intent.ACTION_VIEW, Uri.parse(url)).setPackage("com.google.android.youtube"))
        } catch (e: ActivityNotFoundException) {
            view(url)
        }
        return null
    }

    private fun navigate(place: String): String? {
        try {
            start(Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=" + Uri.encode(place))))
        } catch (e: ActivityNotFoundException) {
            view("geo:0,0?q=" + Uri.encode(place))
        }
        return null
    }

    private fun whatsappShare(text: String): String? {
        start(
            Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text).setPackage("com.whatsapp")
        )
        return null
    }

    // ------------------------------------------------------------- clock etc

    private fun alarm(hour: Int, minute: Int, label: String): String? {
        val i = Intent(AlarmClock.ACTION_SET_ALARM)
            .putExtra(AlarmClock.EXTRA_HOUR, hour.coerceIn(0, 23))
            .putExtra(AlarmClock.EXTRA_MINUTES, minute.coerceIn(0, 59))
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        if (label.isNotBlank()) i.putExtra(AlarmClock.EXTRA_MESSAGE, label)
        start(i)
        return null
    }

    private fun timer(seconds: Int): String? {
        start(
            Intent(AlarmClock.ACTION_SET_TIMER)
                .putExtra(AlarmClock.EXTRA_LENGTH, seconds.coerceIn(1, 86400))
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        )
        return null
    }

    private fun torch(on: Boolean, pa: Boolean): String? {
        val cm = activity.getSystemService(CameraManager::class.java)
        val id = cm.cameraIdList.firstOrNull {
            cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        } ?: return p(pa, "ਇਸ ਫ਼ੋਨ ਵਿੱਚ ਟਾਰਚ ਨਹੀਂ ਲੱਭੀ।", "No flashlight found.")
        cm.setTorchMode(id, on)
        return null
    }

    // ------------------------------------------------------- sound / screen

    private val audio get() = activity.getSystemService(AudioManager::class.java)

    private fun media(cmd: String): String? {
        val code = when (cmd) {
            "pause" -> KeyEvent.KEYCODE_MEDIA_PAUSE
            "next" -> KeyEvent.KEYCODE_MEDIA_NEXT
            "previous" -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
            "stop" -> KeyEvent.KEYCODE_MEDIA_STOP
            else -> KeyEvent.KEYCODE_MEDIA_PLAY
        }
        audio.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        audio.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
        return null
    }

    private fun volume(action: JSONObject): String? {
        val am = audio
        val stream = AudioManager.STREAM_MUSIC
        when (action.optString("change", "")) {
            "up" -> am.adjustStreamVolume(stream, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
            "down" -> am.adjustStreamVolume(stream, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
            "mute" -> am.adjustStreamVolume(stream, AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI)
            "unmute" -> am.adjustStreamVolume(stream, AudioManager.ADJUST_UNMUTE, AudioManager.FLAG_SHOW_UI)
            else -> {
                val level = action.optInt("level", 50).coerceIn(0, 100)
                val max = am.getStreamMaxVolume(stream)
                am.setStreamVolume(stream, Math.round(max * level / 100f), AudioManager.FLAG_SHOW_UI)
            }
        }
        return null
    }

    private fun brightness(level: Int, pa: Boolean): String? {
        if (!Settings.System.canWrite(activity)) {
            start(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:" + activity.packageName)))
            return p(pa, "ਪਹਿਲਾਂ Singh AI ਨੂੰ ਸੈਟਿੰਗ ਬਦਲਣ ਦੀ ਇਜਾਜ਼ਤ ਦਿਓ, ਫਿਰ ਦੁਬਾਰਾ ਕਹੋ।", "Allow Singh AI to modify settings, then ask again.")
        }
        val cr = activity.contentResolver
        Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
        Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS, (level.coerceIn(0, 100) * 255 / 100).coerceAtLeast(5))
        return null
    }

    private fun ringer(mode: String, pa: Boolean): String? {
        return try {
            audio.ringerMode = if (mode == "vibrate") AudioManager.RINGER_MODE_VIBRATE else AudioManager.RINGER_MODE_NORMAL
            null
        } catch (e: SecurityException) {
            p(pa, "Do Not Disturb ਦੀ ਪਰਮਿਸ਼ਨ ਨਹੀਂ।", "Do Not Disturb access is needed for that.")
        }
    }

    private fun global(cmd: String, pa: Boolean): String? {
        val svc = JarvisAccess.instance
            ?: return p(pa, "ਪਹਿਲਾਂ ⚙ ਵਿੱਚ 'ਸਕਰੀਨ ਕੰਟਰੋਲ' ਚਾਲੂ ਕਰੋ।", "Turn on Screen control in ⚙ first.")
        if (cmd == "home" || cmd == "lock" || cmd == "screenshot" || cmd == "notifications" ||
            cmd == "quick_settings" || cmd == "recents"
        ) (activity as? Activity)?.moveTaskToBack(true)
        svc.globalLater(cmd, 500)
        return null
    }

    private fun notifications(pa: Boolean): ActionResult {
        if (!JarvisNotifications.isEnabled(activity)) {
            start(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            return ActionResult(p(pa, "ਪਹਿਲਾਂ Singh AI ਨੂੰ ਨੋਟੀਫਿਕੇਸ਼ਨ ਪੜ੍ਹਨ ਦੀ ਇਜਾਜ਼ਤ ਦਿਓ।", "Allow Singh AI to read notifications first."))
        }
        val data = JarvisNotifications.recentText()
        return if (data.isBlank()) ActionResult(p(pa, "ਕੋਈ ਨਵਾਂ ਨੋਟੀਫਿਕੇਸ਼ਨ ਨਹੀਂ।", "No new notifications, Sir."))
        else ActionResult(followUp = data)
    }

    private fun settings(page: String): String? {
        val action = when (page) {
            "wifi" -> Settings.ACTION_WIFI_SETTINGS
            "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
            "display" -> Settings.ACTION_DISPLAY_SETTINGS
            "sound" -> Settings.ACTION_SOUND_SETTINGS
            "battery" -> Intent.ACTION_POWER_USAGE_SUMMARY
            else -> Settings.ACTION_SETTINGS
        }
        start(Intent(action))
        return null
    }
}
