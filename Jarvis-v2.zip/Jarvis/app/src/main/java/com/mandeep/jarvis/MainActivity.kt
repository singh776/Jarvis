package com.mandeep.jarvis

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.net.ConnectivityManager
import android.net.Network
import android.os.BatteryManager
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {

    private lateinit var reactor: ReactorView
    private lateinit var status: TextView
    private lateinit var netDot: View
    private lateinit var netLabel: TextView
    private lateinit var chat: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var input: EditText
    private lateinit var langBtn: TextView
    private lateinit var actionBtn: TextView
    private lateinit var suggestions: LinearLayout

    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var punjabiVoice = false
    private var listening = false
    private var busy = false
    private var listenAfterSpeech = false
    private var liveBubble: TextView? = null

    private val cyan = Color.parseColor("#3FE0FF")
    private val green = Color.parseColor("#3FFFA8")
    private val red = Color.parseColor("#FF5A6E")
    private val textColor = Color.parseColor("#E8FBFF")

    private val prefs by lazy { getSharedPreferences("jarvis", Context.MODE_PRIVATE) }
    private val brain by lazy { Brain(this) }
    private val actions by lazy { Actions(this) }

    private var punjabi: Boolean
        get() = prefs.getBoolean("punjabi", true)
        set(v) { prefs.edit().putBoolean("punjabi", v).apply() }

    private val keepTalking: Boolean get() = prefs.getBoolean("keep_talking", true)
    private val voiceOn: Boolean get() = prefs.getBoolean("voice_on", true)

    private val netCallback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) { runOnUiThread { updateNet() } }
        override fun onLost(network: Network) { reactor.postDelayed({ updateNet() }, 400) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        reactor = findViewById(R.id.reactor)
        status = findViewById(R.id.status)
        netDot = findViewById(R.id.netDot)
        netLabel = findViewById(R.id.netLabel)
        chat = findViewById(R.id.chat)
        scroll = findViewById(R.id.scroll)
        input = findViewById(R.id.input)
        langBtn = findViewById(R.id.lang)
        actionBtn = findViewById(R.id.action)
        suggestions = findViewById(R.id.suggestions)

        reactor.setOnClickListener { if (listening) stopListening() else startListening() }
        reactor.setOnLongClickListener {
            clearChat()
            toast(if (punjabi) "ਨਵੀਂ ਗੱਲਬਾਤ" else "New conversation")
            true
        }
        langBtn.setOnClickListener {
            punjabi = !punjabi
            refreshLanguage()
        }
        actionBtn.setOnClickListener {
            when {
                input.text.isNotBlank() -> sendTyped()
                listening -> stopListening()
                else -> startListening()
            }
        }
        input.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) = updateActionBtn()
        })
        input.setOnEditorActionListener { _, id, _ ->
            if (id == EditorInfo.IME_ACTION_SEND) { sendTyped(); true } else false
        }
        findViewById<View>(R.id.settings).setOnClickListener { openSettings() }

        refreshLanguage()
        updateActionBtn()
        tts = TextToSpeech(this, this)

        try {
            getSystemService(ConnectivityManager::class.java)?.registerDefaultNetworkCallback(netCallback)
        } catch (e: Exception) { /* not critical */ }

        // Gentle entrance
        reactor.alpha = 0f
        reactor.scaleX = 0.7f
        reactor.scaleY = 0.7f
        reactor.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(700)
            .setInterpolator(DecelerateInterpolator(2f)).start()

        if (brain.apiKey.isEmpty()) reactor.postDelayed({ openSettings() }, 900)
        else if (prefs.getBoolean("auto_listen", false)) reactor.postDelayed({ startListening() }, 900)
        handleAssist(intent)
    }

    override fun onResume() {
        super.onResume()
        refreshLanguage()
        updateNet()
        if (prefs.getBoolean("clear_chat", false)) {
            prefs.edit().putBoolean("clear_chat", false).apply()
            clearChat()
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleAssist(intent)
    }

    /** Opened from the side key / "Digital assistant" gesture: start listening right away. */
    private fun handleAssist(i: Intent?) {
        if (i?.action == Intent.ACTION_ASSIST) reactor.postDelayed({ startListening() }, 400)
    }

    // ---------------------------------------------------------------- voice out

    override fun onInit(result: Int) {
        val engine = tts ?: return
        if (result != TextToSpeech.SUCCESS) {
            setStatus(if (punjabi) "ਆਵਾਜ਼ ਵਾਲਾ engine ਨਹੀਂ ਚੱਲਿਆ" else "Voice engine didn't start")
            return
        }
        ttsReady = true
        punjabiVoice = engine.isLanguageAvailable(Locale("pa", "IN")) >= TextToSpeech.LANG_AVAILABLE
        engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {
                runOnUiThread { reactor.mode = ReactorView.Mode.SPEAKING }
            }

            override fun onDone(utteranceId: String?) {
                runOnUiThread { afterSpeaking() }
            }

            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                runOnUiThread { afterSpeaking() }
            }
        })
        if (!prefs.getBoolean("greeted", false)) {
            prefs.edit().putBoolean("greeted", true).apply()
            say(
                if (punjabi && punjabiVoice) "ਸਤ ਸ੍ਰੀ ਅਕਾਲ ਸਰ! ਮੈਂ ਜਾਰਵਿਸ ਹਾਂ। ਗੋਲੇ ਨੂੰ ਛੂਹੋ ਤੇ ਬੋਲੋ।"
                else "Sat Sri Akal, Sir. Jarvis online. Tap the reactor and speak.",
                listenAfter = false
            )
        }
    }

    private fun say(text: String, listenAfter: Boolean, bubble: Boolean = true) {
        if (bubble && text.isNotBlank()) addBubble(text, Who.JARVIS)
        listenAfterSpeech = listenAfter
        val engine = tts
        if (!voiceOn || !ttsReady || engine == null || text.isBlank()) {
            afterSpeaking()
            return
        }
        engine.setSpeechRate(prefs.getFloat("speech_rate", 1.0f))
        engine.setPitch(prefs.getFloat("pitch", 0.95f))
        val locale = when {
            text.any { it in '਀'..'੿' } && punjabiVoice -> Locale("pa", "IN")
            text.any { it in 'ऀ'..'ॿ' } -> Locale("hi", "IN")
            else -> Locale("en", "IN")
        }
        engine.setLanguage(locale)
        engine.speak(text.replace('\n', ' '), TextToSpeech.QUEUE_FLUSH, null, "jarvis-" + System.currentTimeMillis())
        setStatus(if (punjabi) "ਬੋਲ ਰਿਹਾ ਹਾਂ…" else "Speaking…")
    }

    private fun afterSpeaking() {
        if (reactor.mode != ReactorView.Mode.ERROR) reactor.mode = ReactorView.Mode.IDLE
        setStatus(idleText())
        if (listenAfterSpeech && keepTalking) {
            listenAfterSpeech = false
            startListening()
        }
    }

    // ----------------------------------------------------------------- voice in

    private fun startListening() {
        if (busy) return
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), REQ_MIC)
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            say(
                if (punjabi) "ਇਸ ਫ਼ੋਨ ਵਿੱਚ Google ਦੀ ਸੁਣਨ ਵਾਲੀ ਸੇਵਾ ਨਹੀਂ ਮਿਲੀ। Google app update ਕਰੋ।"
                else "Google speech recognition isn't available. Please update the Google app.",
                false
            )
            return
        }
        tts?.stop()
        recognizer?.destroy()
        val rec = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer = rec
        rec.setRecognitionListener(listener)

        val lang = if (punjabi) "pa-IN" else "en-IN"
        val other = if (punjabi) "en-IN" else "pa-IN"
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, lang)
            .putExtra("android.speech.extra.EXTRA_ADDITIONAL_LANGUAGES", arrayOf(other))
            .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            .putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        listening = true
        reactor.mode = ReactorView.Mode.LISTENING
        setStatus(if (punjabi) "ਸੁਣ ਰਿਹਾ ਹਾਂ… ਬੋਲੋ" else "Listening…")
        updateActionBtn()
        rec.startListening(i)
    }

    private fun stopListening() {
        recognizer?.stopListening()
        listening = false
        updateActionBtn()
    }

    private fun dropLiveBubble() {
        liveBubble?.let { chat.removeView(it) }
        liveBubble = null
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {
            reactor.level = (rmsdB + 2f) / 12f
        }
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {
            reactor.mode = ReactorView.Mode.THINKING
        }

        override fun onError(error: Int) {
            listening = false
            updateActionBtn()
            dropLiveBubble()
            reactor.mode = ReactorView.Mode.IDLE
            val msg = when (error) {
                SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT ->
                    if (punjabi) "ਕੁਝ ਸੁਣਿਆ ਨਹੀਂ — ਦੁਬਾਰਾ ਛੂਹੋ" else "Didn't catch that — tap again"
                SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT ->
                    if (punjabi) "ਇੰਟਰਨੈੱਟ ਚੈੱਕ ਕਰੋ" else "Check the internet"
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS ->
                    if (punjabi) "ਮਾਈਕ ਦੀ ਇਜਾਜ਼ਤ ਦਿਓ" else "Allow the microphone"
                12, 13 -> // language not supported / unavailable
                    if (punjabi) "ਇਹ ਭਾਸ਼ਾ ਫ਼ੋਨ ਵਿੱਚ ਨਹੀਂ — ${langBtn.text} ਬਦਲ ਕੇ ਦੇਖੋ" else "Language not available — switch ${langBtn.text}"
                else -> idleText()
            }
            setStatus(msg)
        }

        override fun onResults(results: Bundle?) {
            listening = false
            updateActionBtn()
            val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
            if (text.isNullOrBlank()) {
                dropLiveBubble()
                reactor.mode = ReactorView.Mode.IDLE
                setStatus(idleText())
            } else {
                handle(text)
            }
        }

        override fun onPartialResults(partialResults: Bundle?) {
            val text = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
            if (text.isNullOrBlank()) return
            val b = liveBubble
            if (b == null) liveBubble = addBubble(text, Who.USER) else b.text = text
            scrollDown()
        }

        override fun onEvent(eventType: Int, params: Bundle?) {}
    }

    // -------------------------------------------------------------------- think

    private fun sendTyped() {
        val text = input.text.toString().trim()
        if (text.isEmpty()) return
        input.setText("")
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(input.windowToken, 0)
        handle(text, fromVoice = false)
    }

    private fun handle(text: String, fromVoice: Boolean = true, showBubble: Boolean = true) {
        if (busy) return
        busy = true
        if (showBubble) {
            val b = liveBubble
            if (b != null) b.text = text else addBubble(text, Who.USER)
        }
        liveBubble = null
        reactor.mode = ReactorView.Mode.THINKING
        setStatus(if (punjabi) "ਸੋਚ ਰਿਹਾ ਹਾਂ…" else "Thinking…")
        val pa = punjabi
        val paVoice = punjabiVoice
        val info = phoneInfo()

        Thread {
            try {
                val result = brain.ask(text, pa, paVoice, info)
                runOnUiThread {
                    busy = false
                    act(text, result, pa, paVoice, fromVoice)
                }
            } catch (e: Exception) {
                runOnUiThread {
                    busy = false
                    showError(e, text, pa)
                }
            }
        }.start()
    }

    /** Friendly error bubble with a retry button (instead of a scary raw message). */
    private fun showError(e: Exception, question: String, pa: Boolean) {
        val msg = Gemini.friendly(e, pa)
        reactor.mode = ReactorView.Mode.ERROR
        addBubble(msg, Who.ERROR)

        val kind = (e as? GeminiException)?.kind
        val needsSettings = kind == GeminiException.Kind.BAD_KEY || kind == GeminiException.Kind.NO_KEY ||
            kind == GeminiException.Kind.BAD_MODEL
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val retry = chip(if (pa) "↻  ਦੁਬਾਰਾ ਕੋਸ਼ਿਸ਼" else "↻  Try again") {}
        retry.setOnClickListener {
            chat.removeView(row)
            reactor.mode = ReactorView.Mode.IDLE
            handle(question, fromVoice = false, showBubble = false)
        }
        row.addView(retry)
        if (needsSettings) {
            val s = chip(if (pa) "⚙  ਸੈਟਿੰਗ ਖੋਲ੍ਹੋ" else "⚙  Open settings") { openSettings() }
            row.addView(s, LinearLayout.LayoutParams(-2, -2).apply { marginStart = dp(8) })
        }
        chat.addView(row, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(6) })
        scrollDown()

        say(msg, listenAfter = false, bubble = false)
        reactor.postDelayed({ if (reactor.mode == ReactorView.Mode.ERROR) reactor.mode = ReactorView.Mode.IDLE }, 2500)
    }

    /** Runs the brain's chosen action, asking for a yes first when it sends something to someone. */
    private fun act(userText: String, result: Reply, pa: Boolean, paVoice: Boolean, fromVoice: Boolean) {
        val action = result.action
        val first = actions.run(action, pa, confirmed = false)
        val question = first.confirm
        if (question == null) {
            complete(userText, result, first, pa, paVoice, fromVoice)
            return
        }
        say(if (pa) "ਭੇਜ ਦਿਆਂ?" else "Shall I send it?", listenAfter = false)
        AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle(if (pa) "ਭੇਜਣਾ ਹੈ?" else "Send this?")
            .setMessage(question)
            .setPositiveButton(if (pa) "ਹਾਂ, ਭੇਜੋ" else "Yes, send") { _, _ ->
                complete(userText, result, actions.run(action, pa, confirmed = true), pa, paVoice, fromVoice)
            }
            .setNegativeButton(if (pa) "ਨਹੀਂ" else "No") { _, _ ->
                say(if (pa) "ਠੀਕ ਹੈ, ਨਹੀਂ ਭੇਜਿਆ।" else "Okay, not sent.", listenAfter = false)
            }
            .setCancelable(false)
            .show()
    }

    private fun complete(userText: String, result: Reply, res: ActionResult, pa: Boolean, paVoice: Boolean, fromVoice: Boolean) {
        val task = res.task
        val data = res.followUp
        when {
            task != null && task.isNotBlank() -> startTask(task, result.say, pa)
            data != null -> {
                busy = true
                reactor.mode = ReactorView.Mode.THINKING
                setStatus(if (pa) "ਪੜ੍ਹ ਰਿਹਾ ਹਾਂ…" else "Reading…")
                Thread {
                    try {
                        val answer = brain.summarize(userText, data, pa, paVoice)
                        runOnUiThread { busy = false; say(answer, listenAfter = false) }
                    } catch (e: Exception) {
                        runOnUiThread { busy = false; showError(e, userText, pa) }
                    }
                }.start()
            }
            else -> {
                val spoken = listOfNotNull(result.say.takeIf { it.isNotBlank() }, res.message).joinToString(" ")
                val type = result.action?.optString("type", "none") ?: "none"
                // Keep the conversation going if Jarvis asked a question (and we didn't leave the app).
                val again = fromVoice && type == "none" && spoken.trim().let { it.endsWith("?") || it.endsWith("？") }
                say(spoken.ifBlank { "…" }, listenAfter = again)
            }
        }
    }

    /** Hands a goal to the screen-control agent, then steps out of the way. */
    private fun startTask(goal: String, sayText: String, pa: Boolean) {
        val svc = JarvisAccess.instance
        if (svc == null) {
            say(
                if (pa) "ਇਸ ਕੰਮ ਲਈ ਪਹਿਲਾਂ ਸਕਰੀਨ ਕੰਟਰੋਲ ਚਾਲੂ ਕਰੋ। ਮੈਂ ਸੈਟਿੰਗ ਖੋਲ੍ਹ ਰਿਹਾ ਹਾਂ।"
                else "Turn on Screen control first, Sir. Opening the setting.",
                listenAfter = false
            )
            reactor.postDelayed({
                try {
                    startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                    toast("Installed apps → Jarvis screen control → ON")
                } catch (e: Exception) { /* ignore */ }
            }, 2500)
            return
        }
        say(sayText.ifBlank { if (pa) "ਹੁਣੇ ਕਰਦਾ ਹਾਂ।" else "On it, Sir." }, listenAfter = false)
        reactor.postDelayed({
            moveTaskToBack(true)
            svc.runTask(goal, pa)
        }, 1200)
    }

    private fun phoneInfo(): String {
        val bm = getSystemService(BatteryManager::class.java)
        val level = bm?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) ?: -1
        val charging = bm?.isCharging == true
        return "Battery: $level%" + (if (charging) " (charging)." else ".")
    }

    // --------------------------------------------------------------------- chat

    private enum class Who { USER, JARVIS, ERROR }

    private fun addBubble(text: String, who: Who): TextView {
        val tv = TextView(this).apply {
            this.text = text
            textSize = if (who == Who.USER) 15f else 16.5f
            setTextColor(if (who == Who.USER) Color.parseColor("#BFF4FF") else textColor)
            setLineSpacing(dp(3).toFloat(), 1f)
            setPadding(dp(14), dp(10), dp(14), dp(10))
            setBackgroundResource(
                when (who) {
                    Who.USER -> R.drawable.bubble_user
                    Who.JARVIS -> R.drawable.bubble_jarvis
                    Who.ERROR -> R.drawable.bubble_error
                }
            )
            maxWidth = (resources.displayMetrics.widthPixels * 0.8f).toInt()
            if (who != Who.USER) setTextIsSelectable(true)
        }
        val lp = LinearLayout.LayoutParams(-2, -2).apply {
            gravity = if (who == Who.USER) Gravity.END else Gravity.START
            topMargin = dp(8)
        }
        chat.addView(tv, lp)
        while (chat.childCount > 40) chat.removeViewAt(0)
        tv.alpha = 0f
        tv.translationY = dp(14).toFloat()
        tv.animate().alpha(1f).translationY(0f).setDuration(280).setInterpolator(DecelerateInterpolator()).start()
        scrollDown()
        return tv
    }

    private fun scrollDown() = scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }

    private fun clearChat() {
        brain.clearHistory()
        chat.removeAllViews()
        liveBubble = null
    }

    private fun chip(label: String, onClick: () -> Unit): TextView = TextView(this).apply {
        text = label
        textSize = 13f
        setTextColor(cyan)
        setBackgroundResource(R.drawable.chip_bg)
        setPadding(dp(14), dp(8), dp(14), dp(8))
        setOnClickListener { onClick() }
    }

    private fun buildSuggestions() {
        suggestions.removeAllViews()
        val items = if (punjabi) listOf("ਟਾਈਮ ਕੀ ਹੋਇਆ?", "ਟਾਰਚ ਚਾਲੂ ਕਰ", "ਮੇਰੇ ਮੈਸੇਜ ਸੁਣਾ", "YouTube ਖੋਲ੍ਹ", "ਬੈਟਰੀ ਕਿੰਨੀ ਹੈ?", "ਅੱਜ ਦਾ ਮੌਸਮ?")
        else listOf("What time is it?", "Torch on", "Read my messages", "Open YouTube", "Battery level?", "Today's weather?")
        for (s in items) {
            suggestions.addView(chip(s) { handle(s, fromVoice = false) },
                LinearLayout.LayoutParams(-2, -2).apply { marginEnd = dp(8) })
        }
    }

    // --------------------------------------------------------------- settings

    private fun openSettings() {
        startActivity(Intent(this, SettingsActivity::class.java))
        overridePendingTransition(R.anim.slide_in_right, R.anim.fade_back)
    }

    // -------------------------------------------------------------------- misc

    private fun refreshLanguage() {
        langBtn.text = if (punjabi) "ਪੰਜਾਬੀ" else "EN"
        input.hint = if (punjabi) "ਲਿਖ ਕੇ ਪੁੱਛੋ…" else "Type to ask…"
        buildSuggestions()
        if (!busy && !listening) setStatus(idleText())
    }

    private fun updateActionBtn() {
        actionBtn.text = when {
            input.text.isNotBlank() -> "➤"
            listening -> "■"
            else -> "🎙"
        }
    }

    private fun updateNet() {
        val online = Gemini.isOnline(this)
        val hasKey = brain.apiKey.isNotEmpty()
        val (color, label) = when {
            !online -> red to (if (punjabi) "ਇੰਟਰਨੈੱਟ ਨਹੀਂ" else "Offline")
            !hasKey -> Color.parseColor("#FFB547") to (if (punjabi) "API key ਨਹੀਂ ਪਾਈ" else "No API key")
            else -> green to (if (punjabi) "ਔਨਲਾਈਨ" else "Online")
        }
        netDot.backgroundTintList = ColorStateList.valueOf(color)
        netLabel.text = label
    }

    private fun idleText() =
        if (punjabi) "ਗੋਲੇ ਨੂੰ ਛੂਹੋ ਤੇ ਬੋਲੋ" else "Tap the reactor and speak"

    private fun setStatus(s: String) {
        status.text = s
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_MIC) {
            if (grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) startListening()
            else setStatus(if (punjabi) "ਮਾਈਕ ਦੀ ਇਜਾਜ਼ਤ ਬਿਨਾਂ ਮੈਂ ਸੁਣ ਨਹੀਂ ਸਕਦਾ" else "I can't listen without the mic permission")
        }
    }

    override fun onDestroy() {
        try {
            getSystemService(ConnectivityManager::class.java)?.unregisterNetworkCallback(netCallback)
        } catch (e: Exception) { /* ignore */ }
        recognizer?.destroy()
        tts?.shutdown()
        super.onDestroy()
    }

    companion object {
        private const val REQ_MIC = 7
    }
}
