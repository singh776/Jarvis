package com.mandeep.jarvis

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.util.AttributeSet
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/**
 * Animated arc-reactor that shows what Jarvis is doing. Tap it to talk.
 * Cyan = ready / listening / speaking, gold = thinking, red = problem.
 * While listening, the outer ring becomes a live voice meter.
 */
class ReactorView(context: Context, attrs: AttributeSet?) : View(context, attrs) {

    enum class Mode { IDLE, LISTENING, THINKING, SPEAKING, ERROR }

    var mode: Mode = Mode.IDLE
        set(value) {
            field = value
            if (value != Mode.LISTENING) level = 0f
            invalidate()
        }

    /** Mic loudness 0..1 while listening. */
    var level: Float = 0f
        set(value) {
            field = value.coerceIn(0f, 1f)
        }

    private val cyan = Color.parseColor("#3FE0FF")
    private val gold = Color.parseColor("#FFB547")
    private val red = Color.parseColor("#FF5A6E")
    private val dimCyan = Color.parseColor("#1A6F80")

    private var color = cyan
    private var angle = 0f
    private var t = 0f
    private var smoothLevel = 0f

    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val tick = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeCap = Paint.Cap.ROUND }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val box = RectF()

    private val animator = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 1000
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener {
            angle += when (mode) {
                Mode.IDLE -> 0.35f
                Mode.LISTENING -> 1.6f
                Mode.THINKING -> 5.5f
                Mode.SPEAKING -> 1.2f
                Mode.ERROR -> 0.2f
            }
            if (angle > 36000f) angle -= 36000f
            t += 0.05f
            smoothLevel += (level - smoothLevel) * 0.25f
            val target = when (mode) {
                Mode.THINKING -> gold
                Mode.ERROR -> red
                else -> cyan
            }
            color = blend(color, target, 0.08f)
            invalidate()
        }
    }

    init {
        // Software layer so the glow (shadow layer) renders on strokes.
        setLayerType(LAYER_TYPE_SOFTWARE, null)
        isClickable = true
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        animator.start()
    }

    override fun onDetachedFromWindow() {
        animator.cancel()
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f
        val cy = height / 2f
        val r = min(width, height) * 0.34f
        if (r <= 0f) return
        val c = color

        val wave = sin(t * 3f)
        val pulse = when (mode) {
            Mode.LISTENING -> 1f + smoothLevel * 0.12f
            Mode.SPEAKING -> 1f + 0.045f * wave
            Mode.THINKING -> 1f + 0.025f * wave
            Mode.ERROR -> 1f + 0.03f * sin(t * 6f)
            Mode.IDLE -> 1f + 0.015f * wave
        }

        // Soft halo behind everything
        val haloR = r * 1.45f
        fill.shader = RadialGradient(
            cx, cy, haloR,
            intArrayOf(alpha(c, 70), alpha(c, 18), Color.TRANSPARENT),
            floatArrayOf(0f, 0.55f, 1f),
            Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, haloR, fill)

        // Tick ring / live voice meter
        tick.color = c
        tick.strokeWidth = r * 0.018f
        val n = 72
        val base = r * 1.06f
        for (i in 0 until n) {
            val a = Math.toRadians(i * 360.0 / n + angle * 0.2)
            val len: Float
            if (mode == Mode.LISTENING) {
                len = r * (0.025f + 0.2f * smoothLevel * (0.55f + 0.45f * sin(i * 0.9f + t * 7f)))
                tick.alpha = 230
            } else if (i % 6 == 0) {
                len = r * 0.07f
                tick.alpha = 170
            } else {
                len = r * 0.03f
                tick.alpha = 80
            }
            val cs = cos(a).toFloat()
            val sn = sin(a).toFloat()
            canvas.drawLine(cx + cs * base, cy + sn * base, cx + cs * (base + len), cy + sn * (base + len), tick)
        }

        ring.setShadowLayer(r * 0.08f, 0f, 0f, c)

        // Outer thin ring
        ring.color = c
        ring.alpha = 140
        ring.strokeWidth = r * 0.02f
        canvas.drawCircle(cx, cy, r * pulse, ring)

        // Segmented rotating ring
        ring.alpha = 255
        ring.strokeWidth = r * 0.085f
        val segR = r * 0.78f * pulse
        box.set(cx - segR, cy - segR, cx + segR, cy + segR)
        for (i in 0 until 10) canvas.drawArc(box, angle + i * 36f, 22f, false, ring)

        // Counter-rotating outer arcs
        ring.color = blend(dimCyan, c, 0.3f)
        ring.strokeWidth = r * 0.04f
        val outR = r * 0.92f * pulse
        box.set(cx - outR, cy - outR, cx + outR, cy + outR)
        for (i in 0 until 4) canvas.drawArc(box, -angle * 1.5f + i * 90f, 55f, false, ring)

        // Inner ring
        ring.color = c
        ring.alpha = 200
        ring.strokeWidth = r * 0.03f
        canvas.drawCircle(cx, cy, r * 0.56f * pulse, ring)

        // Orbiting dots while thinking
        if (mode == Mode.THINKING) {
            fill.shader = null
            fill.color = c
            val orbit = r * 0.66f
            for (i in 0 until 3) {
                val a = Math.toRadians((angle * 2.2 + i * 120.0))
                canvas.drawCircle(cx + cos(a).toFloat() * orbit, cy + sin(a).toFloat() * orbit, r * 0.035f, fill)
            }
        }

        // Glowing core
        val coreR = r * 0.42f * pulse
        fill.shader = RadialGradient(
            cx, cy, coreR,
            intArrayOf(Color.WHITE, c, Color.TRANSPARENT),
            floatArrayOf(0f, 0.45f, 1f),
            Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, coreR, fill)
        fill.shader = null
    }

    private fun alpha(c: Int, a: Int) = Color.argb(a, Color.red(c), Color.green(c), Color.blue(c))

    private fun blend(a: Int, b: Int, f: Float): Int {
        fun mix(x: Int, y: Int) = (x + (y - x) * f).toInt()
        return Color.rgb(mix(Color.red(a), Color.red(b)), mix(Color.green(a), Color.green(b)), mix(Color.blue(a), Color.blue(b)))
    }
}
