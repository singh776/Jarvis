package com.mandeep.jarvis

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import java.util.Locale

/**
 * Proper full-screen settings that slides in smoothly.
 * Everything saves by itself the moment you change it.
 */
class SettingsActivity : Activity(), TextToSpeech.OnInitListener {

    private val prefs by lazy { getSharedPreferences("jarvis", Context.MODE_PRIVATE) }
    private lateinit var root: LinearLayout
    private lateinit var testResult: TextView
    private lateinit var paVoiceStatus: TextView
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var paVoice = false
    private var cardIndex = 0
    private val powerRows = ArrayList<Pair<TextView, () -> Boolean>>()

    private val bg = Color.parseColor("#05080D")
    private val cyan = Color.parseColor("#3FE0FF")
    private val textColor = Color.parseColor("#E8FBFF")
    private val muted = Color.parseColor("#7FA6B0")
    private val green = Color.parseColor("#3FFFA8")
    private val red = Color.parseColor("#FF5A6E")

    private val corePerms = arrayOf(
        Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_CONTACTS,
        Manifest.permission.CALL_PHONE, Manifest.permission.SEND_SMS
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundResource(R.drawable.bg_main)
        }

        // Top bar
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(12), dp(16), dp(6))
        }
        val back = TextView(this).apply {
            text = "←"
            textSize = 22f
            gravity = Gravity.CENTER
            setTextColor(cyan)
            setBackgroundResource(R.drawable.icon_btn)
            setOnClickListener { finish() }
        }
        bar.addView(back, LinearLayout.LayoutParams(dp(46), dp(46)))
        val titles = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), 0, 0, 0)
        }
        titles.addView(TextView(this).apply {
            text = "ਸੈਟਿੰਗ"
            textSize = 24f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(textColor)
        })
        titles.addView(small("ਹਰ ਬਦਲਾਅ ਆਪਣੇ-ਆਪ save ਹੁੰਦਾ ਹੈ"))
        bar.addView(titles)
        outer.addView(bar)

        val scroll = ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            clipToPadding = false
        }
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), 0, dp(16), dp(36))
        }
        scroll.addView(root)
        outer.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(outer)

        // Title bar slides down a little too
        bar.alpha = 0f
        bar.translationY = -dp(16).toFloat()
        bar.animate().alpha(1f).translationY(0f).setDuration(400).setStartDelay(80).start()

        buildBrain()
        buildLanguage()
        buildVoice()
        buildBehaviour()
        buildPowers()
        buildHelp()

        tts = TextToSpeech(this, this)
    }

    override fun onResume() {
        super.onResume()
        refreshPowers()
    }

    override fun finish() {
        super.finish()
        overridePendingTransition(R.anim.fade_back_in, R.anim.slide_out_right)
    }

    override fun onDestroy() {
        tts?.shutdown()
        super.onDestroy()
    }

    // ================================================================ sections

    private fun buildBrain() {
        val c = card("🧠", "ਦਿਮਾਗ — Gemini", "Jarvis Google Gemini ਨਾਲ ਸੋਚਦਾ ਹੈ। ਮੁਫ਼ਤ API key ਲਓ ਤੇ ਹੇਠਾਂ ਪਾਓ।")

        val keyRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val hidden = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        val visible = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
        val key = input("API key ਇੱਥੇ ਪੇਸਟ ਕਰੋ").apply {
            inputType = hidden
            setText(Gemini.apiKey(this@SettingsActivity))
        }
        val eye = iconButton("👁") {}
        eye.setOnClickListener {
            val pos = key.selectionEnd
            key.inputType = if (key.inputType == hidden) visible else hidden
            key.setSelection(pos.coerceIn(0, key.text.length))
        }
        keyRow.addView(key, LinearLayout.LayoutParams(0, dp(52), 1f))
        keyRow.addView(eye, LinearLayout.LayoutParams(dp(48), dp(48)).apply { marginStart = dp(8) })
        c.addView(keyRow, top(14))

        key.addTextChangedListener(watcher {
            prefs.edit().putString("api_key", it.trim()).apply()
            if (::testResult.isInitialized) testResult.text = ""
        })

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(button("📋  ਪੇਸਟ", primary = false) {
            val clip = (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).primaryClip
            val txt = clip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(this)?.toString()?.trim()
            if (txt.isNullOrEmpty()) toast("Clipboard ਖਾਲੀ ਹੈ") else key.setText(txt)
        }, LinearLayout.LayoutParams(0, dp(46), 1f))
        row.addView(button("🔗  Key ਲਓ", primary = false) {
            openUrl("https://aistudio.google.com/apikey")
        }, LinearLayout.LayoutParams(0, dp(46), 1f).apply { marginStart = dp(8) })
        c.addView(row, top(10))

        val test = button("⚡  ਕਨੈਕਸ਼ਨ ਟੈਸਟ ਕਰੋ", primary = true) {}
        c.addView(test, LinearLayout.LayoutParams(-1, dp(50)).apply { topMargin = dp(10) })
        testResult = small("").apply { textSize = 14f }
        c.addView(testResult, top(8))
        test.setOnClickListener {
            val k = key.text.toString().trim()
            if (k.isEmpty()) {
                showResult(false, "✗ ਪਹਿਲਾਂ API key ਪਾਓ।")
                return@setOnClickListener
            }
            testResult.setTextColor(muted)
            testResult.text = "⏳ ਜੁੜ ਰਿਹਾ ਹਾਂ…"
            test.isEnabled = false
            val model = Gemini.model(this)
            Thread {
                val started = System.currentTimeMillis()
                val res: Pair<Boolean, String> = try {
                    Gemini.generateWith(
                        this@SettingsActivity, k, model, "Connection test. Reply with just: OK",
                        JSONArray().put(Gemini.part("user", "ping")), json = false
                    )
                    true to "✓ ਜੁੜ ਗਿਆ! Jarvis ਤਿਆਰ ਹੈ।  ($model · ${System.currentTimeMillis() - started} ms)"
                } catch (e: Exception) {
                    false to "✗ " + Gemini.friendly(e, true) + "\n" + (e.message ?: e.javaClass.simpleName)
                }
                runOnUiThread {
                    test.isEnabled = true
                    showResult(res.first, res.second)
                }
            }.start()
        }

        c.addView(label("Model"), top(18))
        c.addView(small("Flash ⭐ ਸਭ ਤੋਂ ਵਧੀਆ ਹੈ। ਜੇ \"server busy\" ਆਵੇ ਤਾਂ Flash Lite ਵਰਤੋ।"))
        val current = Gemini.model(this)
        val custom = input("ਜਾਂ ਹੋਰ model ਦਾ ਨਾਮ ਲਿਖੋ (ਖਾਲੀ ਵੀ ਠੀਕ)")
        val group = chips(Gemini.MODELS, current) { value ->
            prefs.edit().putString("model", value).apply()
            custom.setText("")
        }
        c.addView(scrollRow(group), top(10))
        if (Gemini.MODELS.none { it.first == current }) custom.setText(current)
        custom.addTextChangedListener(watcher {
            if (it.isNotBlank()) {
                prefs.edit().putString("model", it.trim()).apply()
                group.clearCheck()
            }
        })
        c.addView(custom, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(10) })
    }

    private fun buildLanguage() {
        val c = card("🗣", "ਭਾਸ਼ਾ", null)
        c.addView(label("ਮਾਈਕ ਕਿਹੜੀ ਭਾਸ਼ਾ ਸੁਣੇ"), top(12))
        val mic = chips(listOf("pa" to "ਪੰਜਾਬੀ", "en" to "English"),
            if (prefs.getBoolean("punjabi", true)) "pa" else "en") {
            prefs.edit().putBoolean("punjabi", it == "pa").apply()
        }
        c.addView(scrollRow(mic), top(8))

        c.addView(label("Jarvis ਕਿਹੜੀ ਭਾਸ਼ਾ ਵਿੱਚ ਜਵਾਬ ਦੇਵੇ"), top(16))
        c.addView(small("Auto = ਜਿਸ ਭਾਸ਼ਾ ਵਿੱਚ ਤੁਸੀਂ ਬੋਲੋ, ਉਸੇ ਵਿੱਚ ਜਵਾਬ"))
        val reply = chips(listOf("auto" to "Auto", "pa" to "ਪੰਜਾਬੀ", "en" to "English"),
            prefs.getString("reply_lang", "auto") ?: "auto") {
            prefs.edit().putString("reply_lang", it).apply()
        }
        c.addView(scrollRow(reply), top(8))
    }

    private fun buildVoice() {
        val c = card("🔊", "ਆਵਾਜ਼", null)
        switchRow(c, "ਜਵਾਬ ਬੋਲ ਕੇ ਸੁਣਾਓ", "ਬੰਦ ਕਰੋ ਤਾਂ Jarvis ਸਿਰਫ਼ ਲਿਖ ਕੇ ਜਵਾਬ ਦੇਵੇਗਾ", "voice_on", true)
        seekRow(c, "ਬੋਲਣ ਦੀ ਸਪੀਡ", "speech_rate", 1.0f, 0.5f, 2.0f)
        seekRow(c, "ਆਵਾਜ਼ ਦੀ ਪਿੱਚ (ਮੋਟੀ ↔ ਪਤਲੀ)", "pitch", 0.95f, 0.5f, 1.5f)

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(button("▶  ਆਵਾਜ਼ ਸੁਣੋ", primary = true) { testVoice() },
            LinearLayout.LayoutParams(0, dp(46), 1f))
        row.addView(button("⬇  ਪੰਜਾਬੀ ਆਵਾਜ਼", primary = false) { openTtsSettings() },
            LinearLayout.LayoutParams(0, dp(46), 1f).apply { marginStart = dp(8) })
        c.addView(row, top(14))
        paVoiceStatus = small("ਪੰਜਾਬੀ ਆਵਾਜ਼ ਚੈੱਕ ਕਰ ਰਿਹਾ ਹਾਂ…")
        c.addView(paVoiceStatus, top(8))
    }

    private fun buildBehaviour() {
        val c = card("✨", "ਵਿਹਾਰ", null)
        switchRow(c, "ਗੱਲਬਾਤ ਚੱਲਦੀ ਰੱਖੋ", "Jarvis ਸਵਾਲ ਪੁੱਛੇ ਤਾਂ ਆਪਣੇ-ਆਪ ਫਿਰ ਸੁਣੇ", "keep_talking", true)
        switchRow(c, "ਖੁੱਲ੍ਹਦੇ ਹੀ ਸੁਣਨਾ ਸ਼ੁਰੂ", "App ਖੋਲ੍ਹਦੇ ਹੀ ਮਾਈਕ ਚਾਲੂ", "auto_listen", false)
        c.addView(button("🧹  ਗੱਲਬਾਤ ਸਾਫ਼ ਕਰੋ", primary = false) {
            prefs.edit().putBoolean("clear_chat", true).apply()
            toast("ਗੱਲਬਾਤ ਸਾਫ਼ ✓")
        }, LinearLayout.LayoutParams(-1, dp(46)).apply { topMargin = dp(12) })
    }

    private fun buildPowers() {
        val c = card("🛡", "Jarvis ਦੀਆਂ ਤਾਕਤਾਂ", "ਹਰ ਲਾਈਨ 'ਤੇ ਛੂਹ ਕੇ ✓ ਕਰੋ, ਤਾਂ ਜੋ Jarvis ਫ਼ੋਨ ਦੇ ਸਾਰੇ ਕੰਮ ਕਰ ਸਕੇ।")
        powerRow(c, "🎙  ਮਾਈਕ, ਸੰਪਰਕ, ਕਾਲ, SMS", {
            corePerms.all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }
        }) { requestPermissions(corePerms, REQ_PERMS) }
        powerRow(c, "🤖  ਸਕਰੀਨ ਕੰਟਰੋਲ — ਸਾਰੇ ਕੰਮ", { JarvisAccess.instance != null }) {
            openSetting(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS), "Installed apps → Jarvis screen control → ON")
        }
        powerRow(c, "🔔  ਨੋਟੀਫਿਕੇਸ਼ਨ ਪੜ੍ਹਨਾ", { JarvisNotifications.isEnabled(this) }) {
            openSetting(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS), "Jarvis ਨੂੰ ON ਕਰੋ")
        }
        powerRow(c, "☀  ਬ੍ਰਾਈਟਨੈੱਸ ਬਦਲਣਾ", { Settings.System.canWrite(this) }) {
            openSetting(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName")), "Allow ਕਰੋ")
        }
        powerRow(c, "⭐  ਸਾਈਡ ਬਟਨ ਨਾਲ Jarvis ਖੋਲ੍ਹਣਾ", null) {
            openSetting(Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS), "Digital assistant app → Jarvis ਚੁਣੋ")
        }
    }

    private fun buildHelp() {
        val c = card("ℹ", "ਮਦਦ", null)
        c.addView(button("❓  'Restricted setting' ਆਉਂਦਾ ਹੈ?", primary = false) { showRestrictedHelp() },
            LinearLayout.LayoutParams(-1, dp(46)).apply { topMargin = dp(12) })
        c.addView(button("🔄  ਨਵਾਂ update ਡਾਊਨਲੋਡ ਕਰੋ", primary = false) {
            openUrl("https://github.com/singh776/Jarviss/releases/latest")
        }, LinearLayout.LayoutParams(-1, dp(46)).apply { topMargin = dp(8) })
        val version = try {
            packageManager.getPackageInfo(packageName, 0).versionName
        } catch (e: Exception) { "?" }
        c.addView(small("J.A.R.V.I.S.  v$version").apply { gravity = Gravity.CENTER }, top(14))
    }

    // ================================================================== voice

    override fun onInit(status: Int) {
        ttsReady = status == TextToSpeech.SUCCESS
        val engine = tts
        paVoice = ttsReady && engine != null &&
            engine.isLanguageAvailable(Locale("pa", "IN")) >= TextToSpeech.LANG_AVAILABLE
        if (paVoice) {
            paVoiceStatus.setTextColor(green)
            paVoiceStatus.text = "✓ ਪੰਜਾਬੀ ਆਵਾਜ਼ ਫ਼ੋਨ ਵਿੱਚ ਹੈ"
        } else {
            paVoiceStatus.setTextColor(Color.parseColor("#FFB547"))
            paVoiceStatus.text = "✗ ਪੰਜਾਬੀ ਆਵਾਜ਼ ਨਹੀਂ ਮਿਲੀ। \"⬇ ਪੰਜਾਬੀ ਆਵਾਜ਼\" ਦਬਾਓ → Google → ⚙ → Install voice data → ਪੰਜਾਬੀ।" +
                " ਤਦ ਤੱਕ Jarvis ਅੰਗਰੇਜ਼ੀ ਅੱਖਰਾਂ ਵਿੱਚ ਪੰਜਾਬੀ ਬੋਲੇਗਾ।"
        }
    }

    private fun testVoice() {
        val engine = tts
        if (!ttsReady || engine == null) {
            toast("ਆਵਾਜ਼ ਵਾਲਾ engine ਹਾਲੇ ਤਿਆਰ ਨਹੀਂ")
            return
        }
        engine.setSpeechRate(prefs.getFloat("speech_rate", 1.0f))
        engine.setPitch(prefs.getFloat("pitch", 0.95f))
        val usePa = paVoice && prefs.getBoolean("punjabi", true)
        engine.setLanguage(if (usePa) Locale("pa", "IN") else Locale("en", "IN"))
        engine.speak(
            if (usePa) "ਸਤ ਸ੍ਰੀ ਅਕਾਲ ਸਰ! ਮੈਂ ਜਾਰਵਿਸ ਹਾਂ, ਤੁਹਾਡੀ ਸੇਵਾ ਵਿੱਚ ਹਾਜ਼ਰ।"
            else "Good evening, Sir. Jarvis at your service.",
            TextToSpeech.QUEUE_FLUSH, null, "test"
        )
    }

    private fun openTtsSettings() {
        try {
            startActivity(Intent("com.android.settings.TTS_SETTINGS"))
        } catch (e: Exception) {
            try {
                startActivity(Intent(TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA))
            } catch (e2: Exception) {
                startActivity(Intent(Settings.ACTION_SETTINGS))
            }
        }
    }

    // ================================================================= powers

    private fun powerRow(c: LinearLayout, title: String, check: (() -> Boolean)?, onClick: () -> Unit) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(12))
            setBackgroundResource(R.drawable.btn_bg)
            setOnClickListener { onClick() }
        }
        row.addView(label(title), LinearLayout.LayoutParams(0, -2, 1f))
        val state = TextView(this).apply {
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            text = "›"
            setTextColor(cyan)
        }
        row.addView(state)
        c.addView(row, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
        if (check != null) powerRows.add(state to check)
    }

    private fun refreshPowers() {
        for ((view, check) in powerRows) {
            val ok = try { check() } catch (e: Exception) { false }
            view.text = if (ok) "✓" else "✗"
            view.setTextColor(if (ok) green else red)
        }
    }

    private fun openSetting(i: Intent, hint: String) {
        try {
            startActivity(i)
            Toast.makeText(this, hint, Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            startActivity(Intent(Settings.ACTION_SETTINGS))
        }
    }

    private fun showRestrictedHelp() {
        AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle("Restricted setting")
            .setMessage(
                "Android GitHub ਤੋਂ install ਹੋਈ app ਨੂੰ ਸਕਰੀਨ ਕੰਟਰੋਲ ON ਕਰਨ ਤੋਂ ਰੋਕਦਾ ਹੈ।\n\n" +
                    "1. ਹੁਣ 'App info' ਖੁੱਲ੍ਹੇਗਾ।\n" +
                    "2. ਉੱਪਰ ਸੱਜੇ ⋮ (3 dots) ਦਬਾਓ → \"Allow restricted settings\"।\n" +
                    "3. ਫਿਰ ਇੱਥੇ ਵਾਪਸ ਆ ਕੇ ਸਕਰੀਨ ਕੰਟਰੋਲ ON ਕਰੋ।"
            )
            .setPositiveButton("App info ਖੋਲ੍ਹੋ") { _, _ ->
                startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
            }
            .setNegativeButton("ਬੰਦ ਕਰੋ", null)
            .show()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_PERMS) {
            refreshPowers()
            val ok = grantResults.count { it == PackageManager.PERMISSION_GRANTED }
            toast("$ok/${grantResults.size} ਇਜਾਜ਼ਤਾਂ ✓")
        }
    }

    // =============================================================== builders

    private fun card(icon: String, title: String, sub: String?): LinearLayout {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundResource(R.drawable.card_bg)
            setPadding(dp(18), dp(16), dp(18), dp(18))
        }
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        head.addView(TextView(this).apply { text = icon; textSize = 20f })
        head.addView(TextView(this).apply {
            text = title
            textSize = 17f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(cyan)
            setPadding(dp(10), 0, 0, 0)
        })
        c.addView(head)
        if (sub != null) c.addView(small(sub), top(6))
        root.addView(c, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(14) })

        // Cards float in one after another
        c.alpha = 0f
        c.translationY = dp(30).toFloat()
        c.animate().alpha(1f).translationY(0f)
            .setStartDelay(140L + 90L * cardIndex++)
            .setDuration(450)
            .setInterpolator(DecelerateInterpolator(2f))
            .start()
        return c
    }

    private fun label(s: String) = TextView(this).apply {
        text = s
        textSize = 15f
        setTextColor(textColor)
    }

    private fun small(s: String) = TextView(this).apply {
        text = s
        textSize = 12.5f
        setTextColor(muted)
        setLineSpacing(dp(2).toFloat(), 1f)
    }

    private fun input(hintText: String) = EditText(this).apply {
        hint = hintText
        textSize = 15f
        setSingleLine()
        setTextColor(textColor)
        setHintTextColor(muted)
        setBackgroundResource(R.drawable.input_bg)
        setPadding(dp(14), 0, dp(14), 0)
    }

    private fun button(s: String, primary: Boolean, onClick: () -> Unit) = TextView(this).apply {
        text = s
        textSize = 14.5f
        gravity = Gravity.CENTER
        typeface = if (primary) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        setTextColor(if (primary) bg else cyan)
        setBackgroundResource(if (primary) R.drawable.btn_primary else R.drawable.btn_bg)
        setPadding(dp(10), 0, dp(10), 0)
        setOnClickListener { onClick() }
    }

    private fun iconButton(s: String, onClick: () -> Unit) = TextView(this).apply {
        text = s
        textSize = 18f
        gravity = Gravity.CENTER
        setBackgroundResource(R.drawable.icon_btn)
        setOnClickListener { onClick() }
    }

    private fun chips(options: List<Pair<String, String>>, selected: String, onPick: (String) -> Unit): RadioGroup {
        val group = RadioGroup(this).apply { orientation = RadioGroup.HORIZONTAL }
        val colors = ColorStateList(
            arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
            intArrayOf(bg, cyan)
        )
        for ((value, text) in options) {
            val rb = RadioButton(this).apply {
                id = View.generateViewId()
                this.text = text
                textSize = 14f
                tag = value
                setTextColor(colors)
                setButtonDrawable(android.R.color.transparent)
                setBackgroundResource(R.drawable.chip_bg)
                setPadding(dp(16), dp(9), dp(16), dp(9))
            }
            group.addView(rb, RadioGroup.LayoutParams(-2, -2).apply { marginEnd = dp(8) })
            if (value == selected) rb.isChecked = true
        }
        group.setOnCheckedChangeListener { g, checkedId ->
            val v = g.findViewById<RadioButton>(checkedId)?.tag as? String
            if (v != null) onPick(v)
        }
        return group
    }

    private fun scrollRow(v: View) = HorizontalScrollView(this).apply {
        isHorizontalScrollBarEnabled = false
        addView(v)
    }

    private fun switchRow(c: LinearLayout, title: String, sub: String?, key: String, def: Boolean) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(12), 0, dp(4))
        }
        val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        texts.addView(label(title))
        if (sub != null) texts.addView(small(sub))
        row.addView(texts, LinearLayout.LayoutParams(0, -2, 1f))
        val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
        val sw = Switch(this).apply {
            isChecked = prefs.getBoolean(key, def)
            thumbTintList = ColorStateList(states, intArrayOf(cyan, Color.parseColor("#6B7F87")))
            trackTintList = ColorStateList(states, intArrayOf(Color.parseColor("#883FE0FF"), Color.parseColor("#33FFFFFF")))
            setOnCheckedChangeListener { _, v -> prefs.edit().putBoolean(key, v).apply() }
        }
        row.addView(sw)
        row.setOnClickListener { sw.toggle() }
        c.addView(row)
    }

    private fun seekRow(c: LinearLayout, title: String, key: String, def: Float, min: Float, max: Float) {
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        head.addView(label(title), LinearLayout.LayoutParams(0, -2, 1f))
        val value = TextView(this).apply {
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(cyan)
        }
        head.addView(value)
        c.addView(head, top(16))

        fun toValue(p: Int) = min + (max - min) * p / 100f
        fun show(v: Float) { value.text = String.format(Locale.US, "%.2fx", v) }
        val start = prefs.getFloat(key, def)
        val sb = SeekBar(this).apply {
            this.max = 100
            progress = ((start - min) / (max - min) * 100f).toInt().coerceIn(0, 100)
            progressTintList = ColorStateList.valueOf(cyan)
            thumbTintList = ColorStateList.valueOf(cyan)
            progressBackgroundTintList = ColorStateList.valueOf(Color.parseColor("#33FFFFFF"))
        }
        show(start)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, p: Int, fromUser: Boolean) {
                if (!fromUser) return
                val v = toValue(p)
                show(v)
                prefs.edit().putFloat(key, v).apply()
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        c.addView(sb, top(4))
    }

    private fun showResult(ok: Boolean, s: String) {
        testResult.setTextColor(if (ok) green else red)
        testResult.text = s
    }

    private fun watcher(onChange: (String) -> Unit) = object : TextWatcher {
        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        override fun afterTextChanged(s: Editable?) = onChange(s?.toString() ?: "")
    }

    private fun openUrl(url: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (e: Exception) {
            toast(url)
        }
    }

    private fun top(v: Int) = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(v) }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    companion object {
        private const val REQ_PERMS = 9
    }
}
