package com.mandeep.jarvis

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URL
import java.net.URLEncoder
import java.net.UnknownHostException

/** A Gemini problem, sorted by kind so Jarvis can explain it in plain words. */
class GeminiException(val kind: Kind, message: String, cause: Throwable? = null) : Exception(message, cause) {
    enum class Kind { NO_KEY, NO_INTERNET, BAD_KEY, QUOTA, BAD_MODEL, SERVER, NETWORK, BLOCKED }
}

/**
 * Small Google Gemini REST client (no extra libraries).
 *
 * Fix for "Software caused connection abort":
 *  - never reuses an old (possibly dead) pooled socket: keep-alive off + "Connection: close"
 *  - opens the request on the phone's current active network (WiFi / mobile data / VPN)
 *  - retries up to 3 times with a short wait when the connection drops or Google is busy
 *  - switches to a backup model if the chosen one is missing or overloaded
 */
object Gemini {

    const val DEFAULT_MODEL = "gemini-flash-latest"
    private const val BACKUP_MODEL = "gemini-2.5-flash"
    private const val ATTEMPTS = 3

    /** Models offered in Settings: value to label. */
    val MODELS = listOf(
        "gemini-flash-latest" to "Flash ⭐",
        "gemini-2.5-flash" to "2.5 Flash",
        "gemini-2.5-flash-lite" to "Flash Lite ⚡",
        "gemini-2.5-pro" to "2.5 Pro 🧠",
    )

    init {
        // Dead keep-alive sockets are the #1 cause of "connection abort" on Android.
        System.setProperty("http.keepAlive", "false")
    }

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("jarvis", Context.MODE_PRIVATE)

    fun apiKey(ctx: Context): String = prefs(ctx).getString("api_key", "")?.trim() ?: ""

    fun model(ctx: Context): String =
        prefs(ctx).getString("model", "")?.trim().takeUnless { it.isNullOrEmpty() } ?: DEFAULT_MODEL

    fun part(role: String, text: String): JSONObject =
        JSONObject().put("role", role).put("parts", JSONArray().put(JSONObject().put("text", text)))

    fun isOnline(ctx: Context): Boolean {
        val cm = ctx.getSystemService(ConnectivityManager::class.java) ?: return true
        val caps = cm.getNetworkCapabilities(cm.activeNetwork ?: return false) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    /** Blocking call — run on a background thread. Returns the model's text. */
    fun generate(ctx: Context, system: String, contents: JSONArray, json: Boolean): String =
        generateWith(ctx, apiKey(ctx), model(ctx), system, contents, json)

    /** Same as [generate] but with an explicit key + model (used by the Settings "Test" button). */
    fun generateWith(
        ctx: Context, key: String, model: String, system: String, contents: JSONArray, json: Boolean,
    ): String {
        if (key.isEmpty()) throw GeminiException(GeminiException.Kind.NO_KEY, "No Gemini API key")

        if (!isOnline(ctx)) {
            // The phone may be switching WiFi <-> data: give it a moment.
            Thread.sleep(1500)
            if (!isOnline(ctx)) throw GeminiException(GeminiException.Kind.NO_INTERNET, "No internet")
        }

        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
            .put("contents", contents)
        if (json) body.put("generationConfig", JSONObject().put("responseMimeType", "application/json"))
        val bytes = body.toString().toByteArray(Charsets.UTF_8)

        var current = model
        var usedBackup = false
        var last: GeminiException? = null
        var attempt = 0
        while (attempt < ATTEMPTS) {
            attempt++
            try {
                return requestOnce(ctx, key, current, bytes)
            } catch (e: GeminiException) {
                last = e
                when (e.kind) {
                    GeminiException.Kind.BAD_KEY,
                    GeminiException.Kind.BLOCKED,
                    GeminiException.Kind.NO_KEY -> throw e

                    GeminiException.Kind.BAD_MODEL -> {
                        if (usedBackup || current == BACKUP_MODEL) throw e
                        usedBackup = true
                        current = BACKUP_MODEL
                        attempt-- // a model switch doesn't count as a failed try
                        continue
                    }

                    GeminiException.Kind.SERVER -> if (attempt >= 2 && !usedBackup && current != BACKUP_MODEL) {
                        usedBackup = true
                        current = BACKUP_MODEL
                    }

                    else -> {}
                }
            }
            if (attempt < ATTEMPTS) Thread.sleep(800L * attempt)
        }
        throw last ?: GeminiException(GeminiException.Kind.NETWORK, "Unknown error")
    }

    private fun open(ctx: Context, url: URL): HttpURLConnection {
        val net = ctx.getSystemService(ConnectivityManager::class.java)?.activeNetwork
        val c = if (net != null) net.openConnection(url) else url.openConnection()
        return c as HttpURLConnection
    }

    private fun requestOnce(ctx: Context, key: String, model: String, body: ByteArray): String {
        val url = URL(
            "https://generativelanguage.googleapis.com/v1beta/models/" +
                URLEncoder.encode(model, "UTF-8") + ":generateContent"
        )
        val conn = try {
            open(ctx, url)
        } catch (e: IOException) {
            throw GeminiException(GeminiException.Kind.NETWORK, e.message ?: "open failed", e)
        }
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 20000
            conn.readTimeout = 60000
            conn.doOutput = true
            conn.useCaches = false
            conn.setFixedLengthStreamingMode(body.size)
            conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            conn.setRequestProperty("Connection", "close")
            conn.setRequestProperty("x-goog-api-key", key)

            conn.outputStream.use { it.write(body) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val raw = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""

            if (code !in 200..299) {
                val msg = try {
                    JSONObject(raw).getJSONObject("error").optString("message", raw)
                } catch (e: Exception) { raw }
                val kind = when {
                    code == 401 || code == 403 -> GeminiException.Kind.BAD_KEY
                    code == 400 && (msg.contains("API key", true) || msg.contains("API_KEY")) -> GeminiException.Kind.BAD_KEY
                    code == 404 -> GeminiException.Kind.BAD_MODEL
                    code == 429 -> GeminiException.Kind.QUOTA
                    code >= 500 -> GeminiException.Kind.SERVER
                    else -> GeminiException.Kind.BLOCKED
                }
                throw GeminiException(kind, "Gemini $code: ${msg.take(200)}")
            }
            return extractText(raw)
        } catch (e: GeminiException) {
            throw e
        } catch (e: UnknownHostException) {
            throw GeminiException(GeminiException.Kind.NO_INTERNET, "Can't find Google server (DNS)", e)
        } catch (e: SocketTimeoutException) {
            throw GeminiException(GeminiException.Kind.NETWORK, "Timeout", e)
        } catch (e: IOException) {
            throw GeminiException(GeminiException.Kind.NETWORK, e.message ?: "Connection dropped", e)
        } finally {
            conn.disconnect()
        }
    }

    private fun extractText(raw: String): String {
        val root = JSONObject(raw)
        val cands = root.optJSONArray("candidates")
        if (cands == null || cands.length() == 0) {
            val reason = root.optJSONObject("promptFeedback")?.optString("blockReason") ?: "empty answer"
            throw GeminiException(GeminiException.Kind.BLOCKED, "Blocked: $reason")
        }
        val parts = cands.getJSONObject(0).optJSONObject("content")?.optJSONArray("parts")
            ?: throw GeminiException(GeminiException.Kind.BLOCKED, "Empty answer")
        val sb = StringBuilder()
        for (i in 0 until parts.length()) {
            val p = parts.getJSONObject(i)
            if (!p.optBoolean("thought", false)) sb.append(p.optString("text", ""))
        }
        return sb.toString()
    }

    /** A short, human explanation of what went wrong. */
    fun friendly(e: Exception, pa: Boolean): String {
        val kind = (e as? GeminiException)?.kind ?: GeminiException.Kind.NETWORK
        return when (kind) {
            GeminiException.Kind.NO_KEY ->
                if (pa) "ਪਹਿਲਾਂ ਸੈਟਿੰਗ ਵਿੱਚ Gemini API key ਪਾਓ।" else "Please add your Gemini API key in Settings."
            GeminiException.Kind.NO_INTERNET ->
                if (pa) "ਇੰਟਰਨੈੱਟ ਨਹੀਂ ਚੱਲ ਰਿਹਾ। WiFi ਜਾਂ ਮੋਬਾਈਲ ਡਾਟਾ ਚੈੱਕ ਕਰੋ।" else "No internet. Check WiFi or mobile data."
            GeminiException.Kind.BAD_KEY ->
                if (pa) "API key ਗਲਤ ਹੈ ਜਾਂ ਬੰਦ ਹੋ ਗਈ ਹੈ। ਸੈਟਿੰਗ ਵਿੱਚ ਨਵੀਂ key ਪਾਓ।" else "The API key is wrong or disabled. Add a new key in Settings."
            GeminiException.Kind.QUOTA ->
                if (pa) "ਮੁਫ਼ਤ ਹੱਦ ਪੂਰੀ ਹੋ ਗਈ ਜਾਂ ਬਹੁਤ ਤੇਜ਼ ਸਵਾਲ ਹੋ ਗਏ। ਇੱਕ ਮਿੰਟ ਰੁਕ ਕੇ ਪੁੱਛੋ।" else "Free limit reached or too many requests. Try again in a minute."
            GeminiException.Kind.BAD_MODEL ->
                if (pa) "ਇਹ model ਨਹੀਂ ਮਿਲਿਆ। ਸੈਟਿੰਗ ਵਿੱਚ ਹੋਰ model ਚੁਣੋ।" else "That model wasn't found. Pick another one in Settings."
            GeminiException.Kind.SERVER ->
                if (pa) "Google ਦਾ server ਰੁੱਝਿਆ ਹੋਇਆ ਹੈ। ਥੋੜ੍ਹੀ ਦੇਰ ਬਾਅਦ ਪੁੱਛੋ।" else "Google's server is busy. Try again shortly."
            GeminiException.Kind.BLOCKED ->
                if (pa) "Google ਨੇ ਇਹ ਸਵਾਲ ਰੋਕ ਦਿੱਤਾ। ਹੋਰ ਤਰੀਕੇ ਨਾਲ ਪੁੱਛੋ।" else "Google blocked that request. Try asking differently."
            GeminiException.Kind.NETWORK ->
                if (pa) "ਕਨੈਕਸ਼ਨ ਵਿੱਚੋਂ ਟੁੱਟ ਗਿਆ (3 ਵਾਰ ਕੋਸ਼ਿਸ਼ ਕੀਤੀ)। WiFi ↔ ਡਾਟਾ ਬਦਲ ਕੇ, ਜਾਂ VPN / Private DNS ਬੰਦ ਕਰਕੇ ਦੇਖੋ।"
                else "The connection kept dropping (tried 3 times). Switch WiFi ↔ data, or turn off VPN / Private DNS."
        }
    }
}
