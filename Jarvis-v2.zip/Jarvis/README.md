# J.A.R.V.I.S. — Punjabi + English phone assistant

Samsung Galaxy S26 layi apna Jarvis. Punjabi ja English vich bolo, Jarvis sunda hai, sochda hai (Google Gemini naal) te bol ke jawab dinda hai.

## v2.0 vich nawan ki hai
- **Nawan design:** chat bubbles (puri gall-baat dikhdi), live awaaz meter wala gola, quick-command chips, online/offline dot
- **Connection fix:** "Software caused connection abort" hun nahi aunda — Jarvis purana tutteya connection dobara nahi vartda, 3 vaar aap try karda, te Google busy hove taan backup model te chala janda
- **Saaf galti sunehe:** API key galat, internet band, limit poori — har galti layi seedhi Punjabi gall + "↻ Dubara koshish" button
- **Nawi Settings screen:** hauli slide ho ke khuldi hai — API key (paste, dikhao/lukao, ⚡ Connection test), model, bhasha, awaaz (speed, pitch, test), Jarvis powers ✓/✗

## Ki kar sakda hai
- Har sawal da jawab — Punjabi (ਗੁਰਮੁਖੀ) ja English vich, awaaz naal
- **Kise vi app vich kamm (Screen control):** Jarvis aap screen dekh ke tap, type te scroll karda hai.
  "Wifi band kar", "Instagram te pehli post like kar", "Spotify te Diljit da gaana la", "Uber te ghar di ride dekh", "Screen te ki likhya padh ke suna"
- Call: "Mom nu call kar"
- SMS te WhatsApp: "Harpreet nu WhatsApp kar ki main 10 minute vich aa reha" (bhejan ton pehla puchhda hai)
- Notifications padhna: "Mere messages suna"
- Music: play / pause / agla gaana / pichla
- Volume, brightness, vibrate mode
- Back, Home, Lock screen, Screenshot, Notifications panel
- Apps kholna, YouTube, Google search, Maps
- Alarm, timer, torch, battery, time
- Gall-baat yaad rakhda (gole nu lamba daba ke nawi gall shuru)

Jarvis kade vi paise nahi bhejda, kuch khareedda nahi, te password nahi bharda. Uh kamm tusi aap karna.

## APK kiwen milegi
Is repo vich code push hunde hi **GitHub Actions** aap APK bana dinda hai (3–5 minute).
1. Repo de **Releases** section vich jao (phone te: repo page → "Releases").
2. Sab ton upar wali release vich `Jarvis.apk` te tap karo → download.
3. Install karo (pehli vaar "Install unknown apps" di permission deni paindi hai).

## Pehli vaar setup
1. **API key:** aistudio.google.com/apikey te jao → "Create API key" → copy.
2. Jarvis kholo → ⚙ → key paste karo → **⚡ Connection test** dabao (✓ aana chahida).
3. **Punjabi awaaz:** Settings → General management → Text-to-speech → Google engine → ⚙ → Install voice data → **ਪੰਜਾਬੀ (India)** download karo. (Je eh nahi hove, Jarvis Punjabi English akhran vich bolega.)
4. ⚙ → **Jarvis ਦੀਆਂ ਤਾਕਤਾਂ** vich har line te tap karke ✓ karo:
   - Mic, contacts, call, SMS
   - **Screen control** (sare kamm layi zaroori): Accessibility → Installed apps → Jarvis screen control → ON
   - Notifications padhna
   - Brightness
5. Je Screen control ON na hove te "Restricted setting" likhya aave: Settings → Apps → Jarvis → upar ⋮ → **Allow restricted settings** → fer ON karo.

## Side key naal kholna (asli Jarvis wangu)
Settings → Apps → Default apps → **Digital assistant app** → Jarvis chuno.
Fer side key (ja home button) lamba dabao te Jarvis aap sunna shuru kar dega.

## Buttons
- **Gola (reactor):** tap = bolo, lamba dabao = nawi gall-baat
- **ਪੰਜਾਬੀ / EN:** mic di bhasha badlo
- **➤:** likh ke puchho
- **🎙 / ➤:** khali hove taan mic, likheya hove taan bhejo
- **Chips:** ik tap naal aam kamm
- **⚙:** puri Settings screen
